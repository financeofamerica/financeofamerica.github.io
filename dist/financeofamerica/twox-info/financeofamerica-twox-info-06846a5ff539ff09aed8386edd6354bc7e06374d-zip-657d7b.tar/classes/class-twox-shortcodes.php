<?php


if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}


if (!class_exists('TwoX_Shortcodes')) :
    
	class TwoX_Shortcodes {
		private $allStates = array();

		public function __construct() {
			$this->loadStates();

			add_shortcode( 'twox_full_branchlist', array ($this, 'showAll') );
		}

		public function showAll() {
			$state = "";
			$list = "<div class='branch-listing-wrapper'>";

			$upload_dir   = wp_upload_dir();
			$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
			$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path;
			$filename = get_option('twox_sitekey', false); 
			
			if ( file_exists("{$base_path}/{$filename}.json") ) {
				
				$branches = json_decode(file_get_contents("{$base_path}/{$filename}.json"), true);
				foreach($branches as $branch) {
					if ($branch['state'] != $state) {
						$list .= "<div class='state'>" . $this->allStates[$branch['state']] . "</div>";
						$state = $branch['state'];
					}

					$list .= "<div class='branch'><h4><a href='./" . $branch['id'] . "/'>{$branch['branch_name']} Branch</a></h4>
						{$branch['address']}<br />
						{$branch['city']}, {$branch['state']} {$branch['zip']}
					</div>";
					
				}
			}
			$list .= '</div>'; 
			return $list;
		}

		private function loadStates() {
			$this->allStates = array(
				'AL' => 'Alabama',
				'AK' => 'Alaska',
				'AZ' => 'Arizona',
				'AR' => 'Arkansas',
				'CA' => 'California',
				'CO' => 'Colorado',
				'CT' => 'Connecticut',
				'DE' => 'Delaware',
				'DC' => 'District of Columbia',
				'FL' => 'Florida',
				'GA' => 'Georgia',
				'HI' => 'Hawaii',
				'ID' => 'Idaho',
				'IL' => 'Illinois',
				'IN' => 'Indiana',
				'IA' => 'Iowa',
				'KS' => 'Kansas',
				'KY' => 'Kentucky',
				'LA' => 'Louisiana',
				'ME' => 'Maine',
				'MT' => 'Montana',
				'NE' => 'Nebraska',
				'NV' => 'Nevada',
				'NH' => 'New Hampshire',
				'NJ' => 'New Jersey',
				'NM' => 'New Mexico',
				'NY' => 'New York',
				'NC' => 'North Carolina',
				'ND' => 'North Dakota',
				'OH' => 'Ohio',
				'OK' => 'Oklahoma',
				'OR' => 'Oregon',
				'MD' => 'Maryland',
				'MA' => 'Massachusetts',
				'MI' => 'Michigan',
				'MN' => 'Minnesota',
				'MS' => 'Mississippi',
				'MO' => 'Missouri',
				'PA' => 'Pennsylvania',
				'RI' => 'Rhode Island',
				'SC' => 'South Carolina',
				'SD' => 'South Dakota',
				'TN' => 'Tennessee',
				'TX' => 'Texas',
				'UT' => 'Utah',
				'VT' => 'Vermont',
				'VA' => 'Virginia',
				'WA' => 'Washington',
				'WV' => 'West Virginia',
				'WI' => 'Wisconsin',
				'WY' => 'Wyoming',
			);
		}
	}

endif;