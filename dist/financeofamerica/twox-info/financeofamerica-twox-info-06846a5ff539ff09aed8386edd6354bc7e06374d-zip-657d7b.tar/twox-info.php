<?php
/*
Plugin Name: TwoX Info
Description: Access Data from the 2xLO Rest API
Version: 0.6.3
Author: Chris Carrel
Author URI: https://www.linkedin.com/in/chriscarrel
License:     GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/


if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

require_once dirname( __FILE__ ) . '/lib/ExtendSchedules.php';
require_once dirname( __FILE__ ) . '/lib/autoload.php';
	
use GuzzleHttp\Pool;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Psr\Log\LoggerInterface;

if (!class_exists('TwoX_SiteInfo')) :
	/**
	 *
	 */
	class TwoX_SiteInfo {
		/**
         * @var TwoX_ScheduledTasks
         */
		protected static $tasks = null;

		/**
         * @var GuzzleClient
         */
		protected static $client = null;

		/**
         * @var string
         */
        protected static $url = null;

        /**
         * @var string
         */
		protected static $token = null;
		
		/**
         * @var int
         */
		protected static $expired = null;
		
		/**
         * @var string
         */
		protected static $jsonPath = null;
		

		public static function init() {
			$baseUrl = get_option('twox_endpoint', null);
			$ApiVersion = get_option('twox_version', 'v1');
			$ApiVersion = (is_array($ApiVersion)) ? $ApiVersion[0] : $ApiVersion;
			self::$url = "{$baseUrl}/wp-json/foa/{$ApiVersion}/";

			self::$token = get_option('twox_sitekey', null);     

			$lifetime = (int)get_option('twox_lifetime', '12'); 
			self::$expired = ( time() - ($lifetime * 3600) );

			$filePath = get_site_option( 'twox_info_file_path', false );
			if ($filePath === false) {
				self::validatePath();
				$filePath = get_site_option( 'twox_info_file_path', false );
			}
			self::$jsonPath = $filePath;

			self::includes();
			self::hooks();
		}

		private static function includes() {
			require_once dirname( __FILE__ ) . '/admin/class-twox-info-admin.php';
			require_once dirname( __FILE__ ) . '/endpoints/class-twox-info-controller.php';
			
			require_once dirname( __FILE__ ) . '/classes/class-twox-scheduled-tasks.php';
			self::$tasks = new TwoX_ScheduledTasks();

			require_once dirname( __FILE__ ) . '/classes/class-twox-shortcodes.php';
			new TwoX_Shortcodes();
		}

		private static function hooks() {
			/*
			add_action( 'twox_refresh_branch_json', array( self::$tasks, 'refresh_branch_json'));
			add_action( 'twox_refresh_employee_json', array( self::$tasks, 'refresh_employee_json'));
			*/
			add_action( 'twox_refresh_branchlist_json', array( self::$tasks, 'refresh_branchlist_json'));
			add_action( 'twox_update_branch_post_event', array( self::$tasks, 'refresh_branch_posts_from_api'));
			add_action( 'twox_update_employee_post_event', array( self::$tasks, 'refresh_employee_posts_from_api'));
			add_action( 'twox_fetch_updated_json', array( self::$tasks, 'update_json_files'));

			add_action( 'rest_api_init', array( __CLASS__, 'create_rest_routes' ), 10 );
		}

		private static function validatePath() {
			
			$upload_dir   = wp_upload_dir();
			$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
			$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path ;
				
			// $path = $upload_dir['basedir']. '/' . preg_replace("/[\\/]/", "", urlencode($userPath)) . '/';
			if (!file_exists("{$base_path}/")) {
				mkdir("{$base_path}/", 0744);
			}
			if (!file_exists("{$base_path}/employee/")) {
				mkdir("{$base_path}/employee/", 0744);
			}
			if (!file_exists("{$base_path}/branch/")) {
				mkdir("{$base_path}/branch/", 0744);
			}

			update_site_option( 'twox_info_file_path', "{$base_path}/" );
		}

		public static function create_rest_routes() {
			$controller = new TwoX_REST_Controller;
			$controller->register();
		}

		public static function get_data($file = false, $post_type) {
			if ($file === false) return "";

			$result = "";
			if ( ($post_type == 'employee') || ($post_type == 'branch') ) {

				$json_file = self::$jsonPath . "{$post_type}/{$file}.json";
				if (file_exists($json_file)) {
					$fileTime = filemtime($json_file);
					if ($fileTime < self::$expired) {
						$result = self::fileFetch($post_type, $file);
					} else {
						$result = json_decode(file_get_contents($json_file), true);
					}
				} else {
					$result = self::fileFetch($post_type, $file);
				}
			} 
			
			return $result;
		}

		public static function getLoanOfficer($nmls) {
			return self::findLO('nmls',$nmls);
		}

		public static function findLO($key, $value) {
			$result = false;

			if ( ($key == 'nmls') || ($key == 'lsid') || ($key == 'loid')) {
				try {
					$call = "employee/{$key}/{$value}";
					$response = self::getClient()->get($call);

					if ($response->getStatusCode() == '200') {
						$result = json_decode($response->getBody(true)->getContents(),true);
					} 
					
				} catch (Exception $e) {
					error_log('FindLO Error: ' . $e->getCode() . ' -> ' . $e->getMessage());
				}
			
				return $result;
			} else {
				throw new Exception('Invalid Request - Invalid Lookup KEY provided');
			}
			

		}

		public static function fileFetch($type, $id) {
			$result = false;
			
			$json_file = self::$jsonPath . "{$type}/{$id}.json";
			try {
				$call = "{$type}/id/{$id}";
				$response = self::getClient()->get($call);

				if ($response->getStatusCode() == '200') {
					$content = $response->getBody(true)->getContents();
					if (!$result) {
						$handle = fopen($json_file, 'w');
						fwrite($handle, $content);
						fclose($handle);
					}
					$result = json_decode($content, true);
				} 
				
			} catch (Exception $e) {
				error_log('File Fetch Error: ' . $e->getCode() . ' -> ' . $e->getMessage());
				
				if (file_exists($json_file)) {
					// Fail Nicely if local file exists (even if expired)
					$result = json_decode(file_get_contents($json_file), true);
				}
			}
		
			return $result;
			
		}

		public static function enable_jobs() {
			self::validatePath();
			
			$interval = get_option('twox_frequency', 'twicedaily');
			$interval = (is_array($interval)) ? $interval[0] : $interval;
			
			if ($interval != 'never') {
				
				if (! wp_next_scheduled ( 'twox_update_branch_post_event' )) {
					wp_schedule_event(time(), $interval, 'twox_update_branch_post_event');
				}

				if (! wp_next_scheduled ( 'twox_update_employee_post_event' )) {
					wp_schedule_event(time(), $interval, 'twox_update_employee_post_event');
				}

				if (! wp_next_scheduled ( 'twox_refresh_branchlist_json' )) {
					wp_schedule_event(time(), $interval, 'twox_refresh_branchlist_json');
				}

				if (! wp_next_scheduled ( 'twox_fetch_updated_json' )) {
					wp_schedule_event(time(), $interval, 'twox_fetch_updated_json');
				}
			}
		}

		public static function disable_jobs() {
			wp_clear_scheduled_hook('update_twox_data_event');
			wp_clear_scheduled_hook('update_twox_branch_post_event');
			wp_clear_scheduled_hook('update_twox_employee_post_event');

			wp_clear_scheduled_hook('twox_refresh_branch_json');
			wp_clear_scheduled_hook('twox_update_branch_post_event');
			wp_clear_scheduled_hook('twox_refresh_employee_json');
			wp_clear_scheduled_hook('twox_update_employee_post_event');
			wp_clear_scheduled_hook('twox_refresh_branchlist_json');
			wp_clear_scheduled_hook('twox_update_api_json');
			wp_clear_scheduled_hook('twox_fetch_updated_json');
		}

		
		public static function getPath() {
			return self::$jsonPath;
		}

		/**
         * @return GuzzleClient
         */
        public static function getClient()
        {
            if (!self::$client) {
                self::$client = new Client(
                    [
                        'base_uri' 			=> self::$url,
                        'allow_redirects' 	=> false,
                        'cookies'         	=> false,
						'headers' 			=> ['twoxsite' => self::$token ],
                    ]
                );
            }

            return self::$client;
		}

	}

	add_action( 'plugins_loaded', array( 'TwoX_SiteInfo', 'init' ) );
	register_activation_hook( __FILE__, array( 'TwoX_SiteInfo', 'enable_jobs' ) );
	register_deactivation_hook( __FILE__, array( 'TwoX_SiteInfo', 'disable_jobs' ) );
endif;
