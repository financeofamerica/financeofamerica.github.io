<?php


if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}


if (!class_exists('TwoX_ScheduledTasks')) :
    
	class TwoX_ScheduledTasks {

        /**
		 * @var TwoX_JSON_File_Process
		 */
		protected $file_process;

        public function __construct() {
            require_once dirname( __FILE__ ) . '/class-json-file-process.php';
            $this->file_process = new TwoX_JSON_File_Process();
        }


        public function refresh_branch_posts_from_api() {
            global $wpdb;

            try {
                $call = "branch";
                $response = TwoX_SiteInfo::getClient()->get($call);
                    
                if ($response->getStatusCode() == '200') {
                    $base_path = TwoX_SiteInfo::getPath();

                    $branch_posts = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = '{$call}' AND post_status = 'publish'");     
                    $responseArray = json_decode($response->getBody(true)->getContents(),true);
                    
                    $removed = array_diff($branch_posts, $responseArray['branches']);
                    foreach($removed as $br) {
                        $branch = get_page_by_path( $br, OBJECT, $call );
                        if ($branch) wp_delete_post($branch->ID);
                        if (file_exists($base_path . "/{$call}/{$br}.json")) unlink($base_path . "/{$call}/{$br}.json");
                    }

                    $added = array_diff($responseArray['branches'], $branch_posts);
                    foreach($added as $br) {
                        $this->file_process->push_to_queue( array('type' => 'branch', 'id' => $br) );
                    }
            
                    $this->file_process->save()->dispatch();
                }
            } catch (Exception $e) {
                error_log('Refresh Branch Posts: ' . $e->getCode() . ' -> ' . $e->getMessage());
            }
        }

        public function refresh_employee_posts_from_api() {
            global $wpdb;

            try {
                $call = "employee";
                $response = TwoX_SiteInfo::getClient()->get($call);
                    
                if ($response->getStatusCode() == '200') {
                    $base_path = TwoX_SiteInfo::getPath();

                    $employees = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = '{$call}' AND post_status = 'publish'");
                    $responseArray = json_decode($response->getBody(true)->getContents(),true);
                    
                    $closed = array_diff($employees, $responseArray['employees']);
                    foreach($closed as $br) {
                        $branch = get_page_by_path( $br, OBJECT, $call );
                        if ($branch) wp_delete_post($branch->ID);
                        if (file_exists($base_path . "/{$call}/{$br}.json")) unlink($base_path . "/{$call}/{$br}.json");
                    }

                    $names = array_diff($responseArray['employees'],$employees);
                    foreach ( $names as $name ) {
                        $this->file_process->push_to_queue( array('type' => 'employee', 'id' => $name) );
                    }
            
                    $this->file_process->save()->dispatch();
                }
            } catch (Exception $e) {
                error_log('Refresh Branch Posts: ' . $e->getCode() . ' -> ' . $e->getMessage());
            }
        }


        public function update_json_files() {
            $this->update_json('employee');
            $this->update_json('branch');
        }

        public function update_json($type = 'employee') {
      
            try {
                $hours = ceil(get_site_option('twox_' . $type . '_updates_pulled',time() - (24 * 3600))/time());

                $call = "{$type}/updated/{$hours}";
                $response = TwoX_SiteInfo::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    
                    $base_path = TwoX_SiteInfo::getPath();
            
                    if (file_exists($base_path . "/{$type}/")) {
                        
                        $responseArray = json_decode($response->getBody(true)->getContents(),true);
                        foreach ( $responseArray['updated'] as $name ) {
                            $this->file_process->push_to_queue( array('type' => $type, 'id' => $name) );
                        }
                
                        $this->file_process->save()->dispatch();
                    }
                    update_site_option( 'twox_' . $type . '_updates_pulled', time() - 300 );
                    
                } 
            } catch (Exception $e) {
                error_log('Refresh ' . $type . ' JSON File Error: ' . $e->getCode() . ' -> ' . $e->getMessage());
            }


        }

        public function refresh_branchlist_json() {
      
            try {
                $call = "company/branches";

                $response = TwoX_SiteInfo::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $base_path = TwoX_SiteInfo::getPath();
                    $filename = get_option('twox_sitekey', false); 

                    if ( file_exists($base_path) && ($filename !== false) ) {
                        $handle = fopen("{$base_path}/{$filename}.json", 'w');
                        //write some data here
                        $content = $response->getBody(true)->getContents();
                        fwrite($handle, $content);
                        fclose($handle);
                    }
                    
                } 
            } catch (Exception $e) {
                error_log('Refresh Company Branch List File Error: ' . $e->getCode() . ' -> ' . $e->getMessage());
            }           
        }
    }


endif;