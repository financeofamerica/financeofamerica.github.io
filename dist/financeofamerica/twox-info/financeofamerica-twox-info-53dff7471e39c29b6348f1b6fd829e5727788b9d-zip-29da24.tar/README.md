# Access the TwoX Rest API

Used to read branch and employee data from the TwoX Rest API system

## Description

Used by WordPress sites to access the 2xLO API for branch and LO data

## Installation

If you don't know how to do this, then you probably don't have a need for this plugin

## Frequently Asked Questions

###  Who do I ask if I need assistance? =

Finance of America Marketing Technology Team

