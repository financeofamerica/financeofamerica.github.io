# Changelog

Relevant changes to the TwoX Info project are documented below as a resource for users.

## [0.3.0] - 2018-10-15
### Added
- Create Cron Schedules if they don't exist
- Fix Cron Schedule Frequency Settings

## [0.2.1] - 2018-10-11
### Changed
- Code Cleanup and removed error checking

## [0.2.0] - 2018-10-06
### Added
- Create Branch from JSON file
- Delete Branch Post if JSON is removed
- Create Employee from JSON file
- Delete Employee Post if JSON is removed 

### Changed
- Added "Count" info to admin screen
- Changed from MU Plugin to Standard Plugin (activation hooks)

## [0.1.0] - 2018-10-01
### Added
- Initial Coding to read from 2xLO Rest API 

### Changed
- N/A
