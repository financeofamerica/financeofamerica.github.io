<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('TwoX_AdminSettings')) :
	/* TwoX Info Settings Settings Page */
	class TwoX_AdminSettings {

		public function __construct() {
			add_action( 'admin_menu', array( $this, 'create_settings' ) );
			add_action( 'admin_init', array( $this, 'setup_sections' ) );
			add_action( 'admin_init', array( $this, 'setup_fields' ) );
		}
		public function create_settings() {
			$page_title = 'TwoX Settings';
			$menu_title = 'TwoX Settings';
			$capability = 'manage_options';
			$slug = 'twoxinfo';
			$callback = array($this, 'settings_content');
			$icon = 'dashicons-id-alt';
			$position = 2;
			add_menu_page($page_title, $menu_title, $capability, $slug, $callback, $icon, $position);
		}
		public function settings_content() { ?>
			<div class="wrap">
				<h1>TwoX Settings</h1>
				<?php settings_errors(); ?>
				<form method="POST" action="options.php">
					<?php
						settings_fields( 'twoxinfo' );
						do_settings_sections( 'twoxinfo' );
						submit_button();
					?>
				</form>
				<?php
					global $wpdb;

					$upload_dir   = wp_upload_dir();
					$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
					$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path;
		
					// $emp_dir = $upload_dir['basedir'].'/employee/';
					if (file_exists($base_path . '/employee/')) {
						$employees = array_diff(scandir($base_path . '/employee/'), array('..', '.'));
						$employees = str_replace('.json','', $employees);
				
						$employee_posts = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = 'employees' AND post_status = 'publish'");

						$missing_posts = array_diff($employees,$employee_posts);
						echo "<h4>Employee Counts: " . count($employees) . "(files) - " . count($employee_posts) . "(posts) - " . count($missing_posts) . '(missing)</h4>';
						echo "<pre>" . print_r($missing_posts, true) . "</pre>";
					}
					if (file_exists($base_path . '/branch/')) {
						$branches = array_diff(scandir($base_path . '/branch/'), array('..', '.'));
						$branches = str_replace('.json','', $branches);
						// echo "<h3>Branches</h3><pre>" . print_r($branches, true) . "</pre>";

						$branch_posts = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = 'branches' AND post_status = 'publish'");
						// echo "<h3>Branch Posts</h3><pre>" . print_r($branch_posts, true) . "</pre>";

						$missing_posts = array_diff($branches,$branch_posts);

						echo "<h4>Branch Counts: " . count($branches) . "(files) - " . count($branch_posts) . "(posts) - " . count($missing_posts) . '(missing)</h4>';
						echo "<pre>" . print_r($missing_posts, true) . "</pre>";
					}
				?>
			</div> <?php
		}

		public function setup_sections() {
			add_settings_section( 'twoxinfo_section', 'Configuration settings to access TwoX Rest API system ', array(), 'twoxinfo' );
			
			$update = (isset($_GET['settings-updated'])) ? $_GET['settings-updated'] : false;
			if($update) {
				//do your cron update stuff here.
				TwoX_SiteInfo::disable_jobs();
				TwoX_SiteInfo::enable_jobs();
		   }
		}

		public function setup_fields() {
			$fields = array(
				array(
					'label' => ' TwoX System URL',
					'id' => 'twox_endpoint',
					'type' => 'text',
					'section' => 'twoxinfo_section',
					'desc' => '',
					'placeholder' => ''
				),
				array(
					'label' => 'API Version',
					'id' => 'twox_version',
					'type' => 'select',
					'section' => 'twoxinfo_section',
					'options' => array(
						'v1' => 'v1',
						'v2' => 'v2',
					),
				),
				array(
					'label' => 'Site Key',
					'id' => 'twox_sitekey',
					'type' => 'text',
					'section' => 'twoxinfo_section',
					'desc' => '',
					'placeholder' => ''
				),
				array(
					'label' => 'File Path',
					'id' => 'twox_filepath',
					'type' => 'text',
					'section' => 'twoxinfo_section',
					'desc' => '',
					'placeholder' => ''
				),
				array(
					'label' => 'JSON File Lifetime',
					'id' => 'twox_lifetime',
					'type' => 'select',
					'section' => 'twoxinfo_section',
					'options' => array(
						'0' => 'Never (performance heavy)',
						'12' => 'Twice Daily',
						'24' => ' Daily',
						'48' => '48 Hours',
						'72' => '72 Hours',
						'168' => 'Weekly',
					),
				),
				array(
					'label' => 'Update Interval',
					'id' => 'twox_frequency',
					'type' => 'select',
					'section' => 'twoxinfo_section',
					'options' => array(
						'never' => 'Never',
						'halfhour' => 'Half Hourly',
						'hourly' => 'Hourly',
						'twicedaily' => 'Twice Daily',
						'daily' => ' Daily',
					),
				),
			);
			foreach( $fields as $field ){
				add_settings_field( $field['id'], $field['label'], array( $this, 'field_callback' ), 'twoxinfo', $field['section'], $field );
				register_setting( 'twoxinfo', $field['id'] );
			}
		}

		public function field_callback( $field ) {
			$value = get_option( $field['id'] );
			switch ( $field['type'] ) {
					case 'select':
					case 'multiselect':
						if( ! empty ( $field['options'] ) && is_array( $field['options'] ) ) {
							$attr = '';
							$options = '';
							foreach( $field['options'] as $key => $label ) {
								$options.= sprintf('<option value="%s" %s>%s</option>',
									$key,
									selected($value[array_search($key, $value, true)], $key, false),
									$label
								);
							}
							if( $field['type'] === 'multiselect' ){
								$attr = ' multiple="multiple" ';
							}
							printf( '<select name="%1$s[]" id="%1$s" %2$s>%3$s</select>',
								$field['id'],
								$attr,
								$options
							);
						}
						break;
				default:
					printf( '<input name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" value="%4$s" size="35" />',
						$field['id'],
						$field['type'],
						$field['placeholder'],
						$value
					);
			}
			if( $desc = $field['desc'] ) {
				printf( '<p class="description">%s </p>', $desc );
			}
		}

		
	}

	new TwoX_AdminSettings();

endif;