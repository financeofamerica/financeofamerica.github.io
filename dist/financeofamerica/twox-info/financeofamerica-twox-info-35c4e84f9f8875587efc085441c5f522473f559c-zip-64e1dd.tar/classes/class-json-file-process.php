<?php


class TwoX_JSON_File_Process extends WP_Background_Process {

	/**
	 * @var string
	 */
	protected $action = 'twox_download_json_process';

	
	/**
	 * Task
	 *
	 * @param mixed $item Queue item to iterate over
	 *
	 * @return mixed
	 */
	protected function task( $item ) {
		
		$json = TwoX_SiteInfo::fileFetch($item['type'], $item['id']);
		
		if ($item['type'] == 'branch') {	
			$branch = get_page_by_path( $item['id'], OBJECT, 'branches' );
			if (!$branch) wp_insert_post( array('post_title' => $json->branch_name, 'post_name' => $item['id'], 'post_excerpt' => $this->first_sentence($json->description), 'post_type' => 'branches', 'post_status' => 'publish')) ;
		} elseif ($item['type'] == 'employee') {		
			$employee = get_page_by_path( $item['id'], OBJECT, 'employees' );
			if (!$employee) {
				$intro = (isset($json->short_bio)) ? $json->short_bio : $this->first_sentence($json->long_bio);
				wp_insert_post( array('post_title' => "$json->first_name $json->last_name - $json->job_title ", 'post_name' => $item['id'], 'post_excerpt' => $intro, 'post_type' => 'employees', 'post_status' => 'publish')) ;
			}
		}
		
		return false;
	}

	private function first_sentence($content) {

        $content = html_entity_decode(strip_tags($content));
        $pos = strpos($content, '.');
           
        if($pos === false) {
            return $content;
        }
        else {
            return substr($content, 0, $pos+1);
        }
       
	}
	
	/**
	 * Complete
	 *
	 * Override if applicable, but ensure that the below actions are
	 * performed, or, call parent::complete().
	 */
	protected function complete() {
		parent::complete();

		// Show notice to user or perform some other arbitrary task...
	}

}