<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('TwoX_SchemaBuilder')) :
	/* TwoX Info Schema Builder */
	class TwoX_SchemaBuilder {
        private $version;

		public function __construct() {
            $this->version = 1;
		}
		
		
	}

	new TwoX_SchemaBuilder();

endif;