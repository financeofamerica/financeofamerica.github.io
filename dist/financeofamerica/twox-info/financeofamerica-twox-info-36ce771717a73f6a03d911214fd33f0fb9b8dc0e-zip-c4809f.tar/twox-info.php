<?php
/*
Plugin Name: TwoX Info
Description: Access Data from the 2xLO Rest API
Version: 0.2.1
Author: Chris Carrel
Author URI: https://www.linkedin.com/in/chriscarrel
License:     GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

------------------------------------------------------------------------

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

require_once dirname( __FILE__ ) . '/vendor/autoload.php';

if (!class_exists('TwoX_SiteInfo')) :
	/**
	 *
	 */
	class TwoX_SiteInfo {
		protected static $config;
		
		public static function init() {
			self::includes();
			self::hooks();
		}

		private static function includes() {
			require_once dirname( __FILE__ ) . '/admin/class-twox-info-admin.php';
			require_once dirname( __FILE__ ) . '/endpoints/class-twox-info-controller.php';
		}

		private static function hooks() {
			add_action( 'update_twox_branch_post_event', array( __CLASS__, 'update_branch_posts'));
			add_action( 'update_twox_employee_post_event', array( __CLASS__, 'update_employee_posts'));
			
			add_action( 'rest_api_init', array( __CLASS__, 'create_rest_routes' ), 10 );
		}

		public function create_rest_routes() {
			$controller = new TwoX_REST_Controller;
			$controller->register();
		}

		public static function get_data($file = false, $post_type) {
			if ($file === false) return "";

			$upload_dir = wp_upload_dir(); 
			$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
			$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path;
		
			$result = "";
			if ( ($post_type == 'employee') || ($post_type == 'branch') ) {
				$json_file = $base_path . "/{$post_type}/{$file}.json";
				if (file_exists($json_file)) {
					$result = json_decode(file_get_contents($json_file), true);
				} else {
					error_log("JSON MISSING: {$json_file}");
				}
			} 
			
			return $result;
		}

		public static function enable_jobs() {
			if (! wp_next_scheduled ( 'update_twox_branch_post_event' )) {
				wp_schedule_event(time(), 'hourly', 'update_twox_branch_post_event');
			}

			if (! wp_next_scheduled ( 'update_twox_employee_post_event' )) {
				wp_schedule_event(time(), 'hourly', 'update_twox_employee_post_event');
			}
		}

		public static function disable_jobs() {
			wp_clear_scheduled_hook('update_twox_data_event');
			wp_clear_scheduled_hook('update_twox_branch_post_event');
			wp_clear_scheduled_hook('update_twox_employee_post_event');
		}

		public function update_branch_posts() {
			
			global $wpdb;

			$upload_dir   = wp_upload_dir();
			$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
			$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path;

			if (file_exists($base_path . '/branch/')) {
				$branches = array_diff(scandir($base_path . '/branch/'), array('..', '.'));
				$branches = str_replace('.json','', $branches);
				
				$branch_posts = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = 'branches' AND post_status = 'publish'");
				
				$missing_posts = array_diff($branches,$branch_posts);
				$missing_count = count($missing_posts);
				
				if ($missing_count > 0) {
					$max = ($missing_count > 40) ? 40 : $missing_count;
					$count = 0;
					foreach($missing_posts as $postname) {
						$branch_info = json_decode(file_get_contents($base_path . '/branch/' . "{$postname}.json"));
		
						wp_insert_post( array('post_title' => $branch_info->branch_name, 'post_name' => $postname, 'post_type' => 'branches', 'post_status' => 'publish')) ;
						$count++;
						if ($count >= $max) break;
					}
				}

				$closed = array_diff($branch_posts, $branches);
				if ($closed) {
					foreach($closed as $postname) {
						$branch = get_page_by_path( $postname, OBJECT, 'branches' );
						// if ($branch) wp_update_post(array('ID' => $branch->ID, 'post_status' => 'draft'));
						if ($branch) wp_delete_post($branch->ID);
					}
				}

			}

		}

		public function update_employee_posts() {
			
			global $wpdb;

			$upload_dir   = wp_upload_dir();
			$base_path = preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath','twox-data')));
			$base_path = ($base_path == '') ? $upload_dir['basedir'] : $upload_dir['basedir'] . '/' . $base_path;

			if (file_exists($base_path . '/employee/')) {
				$employees = array_diff(scandir($base_path . '/employee/'), array('..', '.'));
				$employees = str_replace('.json','', $employees);
				
				$emp_posts = $wpdb->get_col("SELECT post_name FROM " . $wpdb->posts . " WHERE post_type = 'employees' AND post_status = 'publish'");
				
				$missing_posts = array_diff($employees,$emp_posts);
				$missing_count = count($missing_posts);
				
				if ($missing_count > 0) {
					$max = ($missing_count > 40) ? 40 : $missing_count;
					$count = 0;
					foreach($missing_posts as $postname) {
						$emp_info = json_decode(file_get_contents($base_path . '/employee/' . "{$postname}.json"));
		
						wp_insert_post( array('post_title' => "$emp_info->first_name $emp_info->last_name - $emp_info->job_title ", 'post_name' => $postname, 'post_type' => 'employees', 'post_status' => 'publish')) ;
						$count++;
						if ($count >= $max) break;
					}
				}

				$terminated = array_diff($emp_posts, $employees);
				if ($terminated) {
					foreach($terminated as $postname) {
						$emp = get_page_by_path( $postname, OBJECT, 'employees' );
						if ($emp) wp_delete_post($emp->ID);
					}
				}
			}

		}

	}

	add_action( 'plugins_loaded', array( 'TwoX_SiteInfo', 'init' ) );
	register_activation_hook( __FILE__, array( 'TwoX_SiteInfo', 'enable_jobs' ) );
	register_deactivation_hook( __FILE__, array( 'TwoX_SiteInfo', 'disable_jobs' ) );
endif;
