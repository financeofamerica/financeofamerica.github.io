<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'TwoX_REST_Controller' ) ) {
	class TwoX_REST_Controller extends WP_REST_Controller {
		protected $type       = null;
		protected $controller = null;
		
		protected static $default_params = array(
			'page'     => 1,
			'per_page' => 10,
			'orderby'  => 'id',
			'order'    => 'ASC',
			'radius' => 100
		);

		public function __construct( $type = null ) {
			$this->namespace = 'twox';
/*
			$upload_dir   = wp_upload_dir();
			$userPath = FOA_Rest_API::get_settings()['twox_jsonfilepath'];
			$userPath = ($userPath == '') ? 'fam-json' : $userPath;

			$this->path = $upload_dir['basedir']. '/' . preg_replace("/[\\/]/", "", urlencode($userPath)) . '/';
*/
		}

		public function register_routes() {
			register_rest_route( $this->namespace, '/info/?', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_info' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			) );
		}

		public function register() {
			$this->register_routes();
		}

		public function get_info( $request ) {
			$info = array (
				'host' => get_option('twox_endpoint'),
				'key' =>  get_option('twox_sitekey'),
				'uploads' =>  preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath'))) 
			);

			return $info;
		}

		public function get_item_permissions_check( $request ) {
			/*
			$key = $request->get_header('foa_sitekey');
			if (!empty($key)) {
				// error_log($key);
				try {
					$args = array(
						'numberposts'	=> 1,
						'post_type'		=> 'foa_company',
						'meta_key'		=> 'site_key',
						'meta_value'	=> $key
					);
					// query
					$posts = get_posts( $args );
					if ($posts) {
						$this->siteID = $posts[0]->ID;
						return true;
					} else {
						$this->siteID = null;
						return false;
					}
				} catch (Exception $e) {
					return  WP_Error( 'foa_permission_check_error', $e->getMessage() , array( 'status' => 404, 'code' => $e->getCode() ) );
				}
			} else {
				return self::validate_sitekey();
			}
			return false;  // should be false
			*/
			return true;
		}

	}
}
