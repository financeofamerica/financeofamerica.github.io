<?php
/**
* Plugin Name: Capsilon Submission Widget
* Description: Upload documents to capsilon IQ
* Version: 1.2
* Author: Point Clear Solutions.
**/
$version = 1.2;



include_once (plugin_dir_path( __FILE__ ) . 'includes/custom-settings.php');

function content_form()
{
    include (plugin_dir_path( __FILE__ ) . 'includes/services.php');
    ?>
            <form id="submission-form" method="POST">
              <div class="container">
                <div class="row h-100 d-lg-flex justify-content-center">
                  <div class="col-sm-12 col-md-6">
                    <div class="form-group">
                      <label for="firstname">Name<span class="required-color">*<span></label>
                      <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Name"/>
                    </div>
                    <div class="form-group">
                      <label for="email">Email<span class="required-color">*<span></label>
                      <input type="email" class="form-control" id="email" name="email" placeholder="Email"/>
                    </div>
                    <div class="form-group">
                      <label for="loan">Loan Number</label>
                      <input type="text" class="form-control" id="loan" name="loan" placeholder="Loan Number"/>
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-6">
                    <div class="form-group" style="height:100%;">
                      <label for="msg">Comments</label>
                      <textarea style="height:85%;" type="text" class="form-control messageArea" id="msg" name="msg" placeholder="Comments"></textarea>
                    </div>
                    <input type="hidden" id="guid" name="guid" value="">
                  </div>
                </div>
                <div class="row h-100 d-flex justify-content-center">
                  <div class="col-12">
                    <div class="form-group docs-top">
                    <div class="infoWrapper">
                      <label for="upload" class="upload-title">Documents to upload</label>
                      <p class="upload-msg">This is a secure site hosted by Finance of America Mortgage and powered by an Ellie Mae application</p>
                    </div>
                    <div id="upload" class="upload"></div>
                    <div class="infoWrapper">
                      <p  class="docs-msg">*You should select at least one document to start the upload process.</p>
                      <p  class="docs-supported">Supported files (*.pdf, *.xml, *.json, *.html, *.txt, *.png, *.jpeg, *.tif, *.tiff)</p>
                    </div>
                    <div class="filelists">
                      <label id="complete_label" class="d-none f-complete">Complete</label>
                      <ol class="filelist complete">
                      </ol>
                      <label id="queued_label" class="d-none" >Queued</label>
                      <ol class="filelist queue">
                      </ol>
                      <label id="error_label" class="d-none" >Error:</label>
                      <ol class="filelist errorList">
                      </ol>
                      <div>
                        <button type="submit" id="submit" name="submit" class="col-12 start_all btn btn-primary">Start Upload</button>
                      </div>
                  </div>
                  </div>
                  </div>
                </div>
              </div>
            </form>
    <?php
    return ob_get_clean();
}

wp_enqueue_script('toast_js', plugin_dir_url(__FILE__) . 'includes/node/jquery.toast.min.js', array('jquery'));
wp_enqueue_script('core_js', plugin_dir_url(__FILE__) . 'includes/node/core.js', array('jquery'));
wp_enqueue_script('upload_js', plugin_dir_url(__FILE__) . 'includes/node/upload.js', array('jquery'));
wp_enqueue_script('validate_js', plugin_dir_url(__FILE__) . 'includes/node/jquery.validate.min.js', array('jquery'));
wp_enqueue_script('docs', plugins_url( '/partials/js/docs.js', __FILE__), '', '1.2');
wp_enqueue_script('validations', plugins_url( '/partials/js/validations.js', __FILE__), '', '1.2');
wp_enqueue_style('upload_theme_css', plugins_url('/includes/node/themes/light.css', __FILE__));
wp_enqueue_style('upload_theme_light_css', plugins_url('/includes/node/themes/upload.css', __FILE__));
wp_enqueue_style('upload_css', plugins_url('/includes/node/upload.css', __FILE__));
wp_enqueue_style('styles_css', plugins_url('/partials/css/styles.css', __FILE__), '', '1.2');
wp_enqueue_style('error_css', plugins_url('/partials/css/error.css', __FILE__), '', '1.2');
wp_enqueue_style('toast_css', plugins_url('/includes/node/jquery.toast.min.css', __FILE__));
add_shortcode('content-form', 'content_form');
