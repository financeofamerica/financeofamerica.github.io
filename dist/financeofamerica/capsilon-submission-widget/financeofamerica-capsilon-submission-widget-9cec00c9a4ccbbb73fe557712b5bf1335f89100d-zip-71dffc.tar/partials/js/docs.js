jQuery(document).ready(function($) {
    let errorFiles = [];
    let formValues = [];
    let filesArray = [];
    let filesComplete = [];

    Formstone.Ready(function() {
        $(".upload").upload({
                autoUpload: false,
                leave: 'You have uploads pending, are you sure you want to leave this page?',
                multiple: true,
                theme: 'fs-light'
            })
            .on("start.upload", onStart)
            .on("queued.upload", onQueued)
            .on("click", ".cancel", onCancel);
        $(".filelist.queue").on("click", ".cancel", onCancel);
    });

    function onCancel(e) {
        let index = $(this).parents("li").data("index");
        $(this).parents("form").find(".filelist.queue").find("li[data-index=" + index + "]").remove();
        checkQueued();
        filesArray = filesArray.filter(elem => {
            return elem.index !== index;
        });
    }

    function onStart(e, files) {
        $("#submission-form").valid();
        formValues = $("#submission-form").serializeArray();
        generateSiteId(filesArray, formValues);
        $('#submit').attr("disabled", true);
    }

    function onQueued(e, files) {
        removeErrorFiles(filesComplete, filesArray);
        files.map(file => { filesArray.push(file) });
        if (filesArray.length <= 10) {
            files.map((res) => {
                let extensions = /(\.png|\.jpeg|\.pdf|\.tif|\.tiff|\.xml|\.json|\.html|.txt)$/i;
                if (!extensions.exec(res.name)) {
                    let msg = `File extension not supported!, file: ${res.name}`;
                    showToastMsg(msg, 'red');
                    errorFiles.push(res);
                } else {
                    let html = '';
                    $("#queued_label").removeClass("d-none");
                    html += '<li data-index="' + res.index + '"><div class="content"><div class="file">' + res.name + '</div><div class="cancel">Cancel</div><div class="progress">Queued</div></div><div class="bar"></div></li>';
                    $(this).parents("form").find(".filelist.queue").append(html);
                }
            });
        } else {
            errorFiles = files;
            showToastMsg('You can not upload more than 10 files at once', 'red');
            removeErrorFiles(errorFiles, filesArray);
        }
        removeErrorFiles(errorFiles, filesArray);
    }

    function generateSiteId(filesArray, formValues) {
        $.ajax({
            url: ajax_object.siteId,
            processData: false,
            contentType: false,
            type: 'POST',
            success: function(response) {
                generateUserTicket(response, filesArray, formValues);
            },
            error: function(request, status, error) {
                let msg = `An error occurred while processing your request`;
                showToastMsg(msg, 'red');
            }
        });
    }

    function generateUserTicket(siteId, filesArray, formValues) {
        let data = new FormData();
        data.append('siteId', siteId);
        data.append('tickets', filesArray.length);
        $.ajax({
            url: ajax_object.userTicket,
            data: data,
            processData: false,
            contentType: false,
            type: 'POST',
            success: function(response) {
                let values = JSON.parse(response);
                if ($.isArray(values.applicationTicket)) {
                    values.applicationTicket.map((res, index) => {
                        sendDocuments(res.id, values.userTicketId, filesArray[index], formValues);
                        if (index + 1 === values.applicationTicket.length) {
                            filesArray = [];
                        }
                    });
                } else {
                    sendDocuments(values.applicationTicket.id, values.userTicketId, filesArray[0], formValues);
                    filesArray = [];
                }
            },
            error: function(request, status, error) {
                let msg = `An error occurred while processing your request`;
                showToastMsg(msg, 'red');
            }
        });
    }

    function sendDocuments(ticket, userTicket, file, formValues) {
        onFileStart(file, ticket, userTicket, formValues);
    }

    function uploadErrorMsg(file, response) {
        let error = (JSON.parse(response));
        if (error["exception"] !== undefined || response === '') {
            let err = [];
            err.push(file);
            onFileError('', file);
            checkError();
            removeErrorFiles(err, filesArray);
        }
    }

    function checkCompleted() {
        if ($('ol.filelist.complete li').length >= 1) {
            $("#complete_label").removeClass("d-none");
        } else {
            $("#complete_label").addClass("d-none")
        }
    }

    function checkError() {
        if ($('ol.filelist.errorList li').length >= 1) {
            $("#error_label").removeClass("d-none");
        } else {
            $("#error_label").addClass("d-none")
        }
    }

    function checkQueued() {
        ($('ol.filelist.queue li').length < 1) ? $("#queued_label").addClass("d-none"): $("#queued_label").removeClass("d-none");
    }

    function onFileComplete(e, file) {
        filesComplete.push(file);
        let $target = $("#submission-form").find("ol.filelist.queue").find("li[data-index=" + file.index + "]");
        $target.find(".file").text(file.name);
        $target.find(".progress").remove();
        $target.find(".cancel").remove();
        $target.addClass("success-border");
        $target.find(".content").append('<div class="success-text">Complete</div>');
        $target.appendTo($("#submission-form").find("ol.filelist.complete"));
        $('#submit').removeAttr("disabled");
    }

    function onFileError(e, file) {
        filesComplete.push(file);
        let $target = $("#submission-form").find("ol.filelist.queue").find("li[data-index=" + file.index + "]");
        $target.find(".file").text(file.name);
        $target.find(".progress").remove();
        $target.find(".cancel").remove();
        $target.addClass("error-border");
        $target.find(".content").append('<div class="error-text">An error occurred while uploading this file</div>');
        $target.appendTo($("#submission-form").find("ol.filelist.errorList"));
        $('#submit').removeAttr("disabled");
    }

    function onFileStart(file, ticket, userTicket, formValues) {
        $(this).parents("form").find(".filelist.queue").find("li[data-index=" + file.index + "]").find(".progress").text("0%");
        let data = new FormData();
        let msg = formatMsg(formValues);
        let subject = `Consumer Documents - ${formValues[0].value}`;
        data.append('file', file.file);
        data.append('msg', msg);
        data.append('subject', subject);
        data.append('ticket', ticket);
        data.append('userTicket', userTicket);
        data.append('folderId', formValues[4].value);

        $.ajax({
            url: ajax_object.sendDocuments,
            data: data,
            processData: false,
            contentType: false,
            type: 'POST',
            success: function(response) {
                uploadErrorMsg(file, response)
                onFileComplete('', file);
                checkQueued();
                checkCompleted();
            },
            error: function(request, status, error) {
                let msg = `An error has occurred while uploading: ${file.name}`;
                showToastMsg(msg, 'red');
                $('#submission-form').find('input:text').val('');
                onFileError(e, file);
                checkError();
                removeNoneEvents();
            }
        });
    }

    function formatMsg(formValues) {
      let  msg;
      if (formValues[2].value === '' &&  formValues[3].value === '') {
        msg = ` \n 
        \n Name: ${formValues[0].value} 
        \n Email: ${formValues[1].value}
        `;
      }
      if (formValues[2].value === '' && formValues[3].value !== '') {
          msg = ` \n 
        \n Name: ${formValues[0].value} 
        \n Email: ${formValues[1].value} 
        \n Comments: ${formValues[3].value} 
        `;
      }

      if (formValues[3].value === '' && formValues[2].value !== '') {
          msg = ` \n
        \n Name: ${formValues[0].value} 
        \n Email: ${formValues[1].value} 
        \n Loan Number: ${formValues[2].value} 
        `;
      }

      if (formValues[3].value !== '' && formValues[2].value !== '') {
        msg = ` \n
        \n Name: ${formValues[0].value} 
        \n Email: ${formValues[1].value} 
        \n Loan Number: ${formValues[2].value} 
        \n Comments: ${formValues[3].value} 
      `;
      }
      return msg;
    }

    function showToastMsg(msg, color) {
        $.toast({
            text: msg,
            showHideTransition: 'slide',
            bgColor: color,
            textColor: '#fff',
            allowToastClose: false,
            hideAfter: 5000,
            stack: 5,
            textAlign: 'left',
            position: 'top-right'
        });
    }

    function removeErrorFiles(errorFiles, filesArray) {
        errorFiles.map((res) => {
            filesArray.map((file, i) => {
                if (res.index === file.index) {
                    filesArray.splice(i, 1);
                }
            });
        });
    }

    function removeNoneEvents() {
        $('#firstname').removeClass("pointer");
        $('#lastname').removeClass("pointer");
        $('#email').removeClass("pointer");
        $('#subject').removeClass("pointer");
        $('#msg').removeClass("pointer");
        $('#upload').removeClass("pointer");
    }
});
