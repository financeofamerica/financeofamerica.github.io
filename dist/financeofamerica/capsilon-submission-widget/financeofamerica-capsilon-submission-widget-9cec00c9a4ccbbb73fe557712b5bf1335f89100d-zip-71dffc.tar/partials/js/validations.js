jQuery(document).ready(function($) {
    $.validator.addMethod(
        "regex",
        function(value, element, regexp) {
            if (regexp && regexp.constructor != RegExp) {
                regexp = new RegExp(regexp);
            } else if (regexp.global) regexp.lastIndex = 0;
            return this.optional(element) || regexp.test(value);
        },
        'Please enter a valid email.'
    );
    $.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-z áãâäàéêëèíîïìóõôöòúûüùçñ]+$/i.test(value);
    }, "Only letters are allowed.");

    $("#submission-form").validate({
        rules: {
            "firstname": {
                required: true,
                minlength: 1,
                lettersonly: true
            },
            "email": {
                required: true,
                email: true,
                regex: /^\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i
            },
            "loan": {
                digits: true,
                required: false,
            }
        },
        messages: {
            "firstname": {
                required: "Please enter a name"
            },
            "email": {
                required: "Please enter an email",
                email: "Please enter a valid email."
            },
        },
        submitHandler: function() {
            if (($('ol.filelist.queue li').length >= 1)) {
                $('#submission-form').find(".upload").upload("start");
                $('#submission-form').find(".filelist.queue")
                    .find("li")
                    .find(".progress").text("Waiting");
            }
        }
    });

    function sendInfo() {
        $('#firstname').addClass("pointer");
        $('#lastname').addClass("pointer");
        $('#email').addClass("pointer");
        $('#subject').addClass("pointer");
        $('#msg').addClass("pointer");
        $('#upload').addClass("pointer");
    }
});