<?php
    $path = preg_replace('/wp-content(?!.*wp-content).*/','',__DIR__);
    require_once($path.'/wp/wp-load.php');

    $applicationTicketId= $_POST['ticket'];
    $userTicketId= $_POST['userTicket'];
    $cfile = $_FILES['file'];
    $folderId = $_POST['folderId'];
    $msg =  $_POST['msg'];
    $subject = $_POST['subject'];
    $submissionCert = get_option('submission_cert');

    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/MailitemInterface/startTransmission",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_HTTPHEADER => array(
        "applicationTicketId: $applicationTicketId"
      ),
      CURLOPT_SSLCERT =>  "cert.p12", 
      CURLOPT_SSLCERTTYPE => "P12",
      CURLOPT_SSLKEYPASSWD => $submissionCert
    ));
  
    $response = curl_exec($curl);
    if(curl_exec($curl) === false) {
      echo `There was an error generating the transmition id`;
    }
    
  return generateFileId($response, $applicationTicketId, $folderId, $cfile, $msg, $submissionCert, $userTicketId, $subject);
  curl_close($curl);

  function generateFileId($transmissionId, $applicationTicketId, $folderId, $cfile, $msg, $submissionCert, $userTicketId, $subject) {
    $file = new CURLFile($cfile['tmp_name'], $cfile['type'], $cfile['name']);
    $name = $cfile['name'];

    switch ($cfile['type']) {
      case "application/json":
        $type = "JSON";
        $mimeType = "type";
        $index = "INDEX_BY_SENDER";
        break;
      case "text/html":
        $type = "HTML";
        $mimeType = "type";
        $index = "INDEX_BY_SENDER";
        break;
      case "text/plain":
        $type = "TEXT_PLAIN";
        $mimeType = "type";
        $index = "INDEX_BY_SENDER";
        break;
      case "text/xml":
        $type = "MISMO_3_3_XML";
        $mimeType = "type";
        $index = "INDEX_BY_SENDER";
        break;
      default:
        $type = $cfile['type'];
        $mimeType = "mime";
        $index = "AUTO_INDEXING";
        break;
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://awh1-standard-u1.docvelocity-na8.net/upload-gateway/HttpUpload",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => array(
          'applicationTicketId' => $applicationTicketId,
          'Upload'=> $file,
          'transmissionId' => $transmissionId),
        CURLOPT_HTTPHEADER => array(
          "Content-Type: multipart/form-data"
        ),
        CURLOPT_SSLCERT =>  "cert.p12", 
        CURLOPT_SSLCERTTYPE => "P12",
        CURLOPT_SSLKEYPASSWD => $submissionCert
    ));
    
      $response = curl_exec($curl);
      $xml = simplexml_load_string($response);
      $response = json_decode(str_replace('@', '', json_encode($xml)));
    
      if(curl_exec($curl) === false) {
        echo `There was an error generating fileId for your document, please try again.`;
        }
      else
      {
          sendSmartDocuments(
          $response->files->file->attributes->id,  
          $applicationTicketId, 
          $transmissionId, 
          $folderId, 
          $subject,
          $msg,
          $submissionCert,
          $type, 
          $name,
          $mimeType,
          $index,
          $userTicketId
          );
      }
    curl_close($curl);
  }
    
  function sendSmartDocuments($fileId, $applicationTicketId, $transmissionId, $folderId, $subject, $note, $submissionCert, $type, $name, $mimeType, $index, $userTicketId) {

    if ($mimeType  == "mime") {
      $content = "contextId={$folderId}&transmissionId={$transmissionId}&channel=channel&subject={$subject}&note={$note}&autoCreateDocuments=true&indexingOption=$index&documentDetailXML=%3CsmartDocuments%3E%0A%09%3CsmartDocument%20documentDictionaryName%3D%22standard%22%20docTypeName%3D%22Unknown%22%3E%0A%09%09%3Cpayloads%3E%0A%09%09%09%3CviewFiles%3E%0A%09%09%09%09%3CviewFile%20payloadId%3D%22{$fileId}%22%20name%3D%22{$name}%22%20mimeType%3D%22{$type}%22/%3E%0A%09%09%09%3C/viewFiles%3E%0A%09%09%3C/payloads%3E%0A%09%3C/smartDocument%3E%0A%3C/smartDocuments%3E";
    } else {
      $content = "contextId={$folderId}&transmissionId={$transmissionId}&channel=channel&subject={$subject}&note={$note}&autoCreateDocuments=true&indexingOption=$index&documentDetailXML=%3CsmartDocuments%3E%0A%09%3CsmartDocument%20documentDictionaryName%3D%22standard%22%20docTypeName%3D%22Note%22%3E%0A%09%09%3Chint%3E%0A%09%09%09%3C%21%5BCDATA%5B{$name}%5D%5D%3E%0A%09%09%3C/hint%3E%0A%09%09%3CdisplayStatus%3E%0A%09%09%09%3C%21%5BCDATA%5BNew%20Document%5D%5D%3E%0A%09%09%3C/displayStatus%3E%0A%09%09%3Cpayloads%3E%0A%09%09%09%3CsmartDocumentFile%20payloadId%3D%22{$fileId}%22%20type%3D%22{$type}%22%20name%3D%22{$name}%22/%3E%0A%09%09%3C/payloads%3E%0A%09%3C/smartDocument%3E%0A%3C/smartDocuments%3E%0A";
    }

    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/MailitemInterface/uploadSmartDocuments",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS =>  $content,
      CURLOPT_HTTPHEADER => array(
        "applicationTicketId: $applicationTicketId",
        "Content-Type: application/x-www-form-urlencoded"
      ),
      CURLOPT_SSLCERT => "cert.p12", 
      CURLOPT_SSLCERTTYPE => "P12",
      CURLOPT_SSLKEYPASSWD => $submissionCert
    ));
    
    $response = curl_exec($curl);

    if(curl_exec($curl) === false)
    {
      echo `There was an error uploading your document, please try again`;
    } 
    
    clearApplicationTicket($applicationTicketId, $userTicketId, $response);
    curl_close($curl);
  }

  function clearApplicationTicket($applicationTicketId, $userTicketId, $uploadMsg) {
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/ApplicationTicketInterface/clearApplicationTickets",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS =>"{\n\"stringCollection\": {\n\"elements\": [\n\"0951C1CA-8D26-643A-096A-60991807DBAA\"\n]\n}\n}",
      CURLOPT_HTTPHEADER => array(
        "applicationTicketId: $applicationTicketId",
        "Content-Type: application/json"
      ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);
    echo $uploadMsg;
  }

  function userTicketLogout($userTicketId, $uploadMsg)  {
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/UserTicketInterface/logOut",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_HTTPHEADER => array(
        "userTicketId: $userTicketId"
      ),
    ));

    $response = curl_exec($curl);

    echo $uploadMsg;
    curl_close($curl);
  }