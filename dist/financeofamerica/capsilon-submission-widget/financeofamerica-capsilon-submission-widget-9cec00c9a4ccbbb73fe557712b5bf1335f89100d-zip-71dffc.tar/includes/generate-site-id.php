<?php
    $path = preg_replace('/wp-content(?!.*wp-content).*/','',__DIR__);
    require_once($path.'/wp/wp-load.php');
    
    $appName = get_option('submission_app_name');
    $appSecret = get_option('submission_app_secret');
    $siteAddress= get_option('submission_site_address');

    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://fam.docvelocity-na8.net/HUB/services/rest/ApplicationService/validateApplicationAndSite",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => "siteAddress={$siteAddress}&applicationName={$appName}&applicationSecret={$appSecret}",
      CURLOPT_HTTPHEADER => array(
        "Content-Type: application/x-www-form-urlencoded",
      ),
    ));
    $response = curl_exec($curl);
    if(curl_exec($curl) === false)  {
      echo 'An error occurred while processing your request';
    }
    
    curl_close($curl);
    $response = json_decode($response);
    echo  $response->validateApplicationAndSiteResult->siteId;
