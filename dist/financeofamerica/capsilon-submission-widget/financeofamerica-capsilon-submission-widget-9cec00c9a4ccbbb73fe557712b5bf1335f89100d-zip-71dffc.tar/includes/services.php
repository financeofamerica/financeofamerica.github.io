<?php

function getSiteId($siteAddress, $appName, $appSecret)
{
  
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://fam.docvelocity-na8.net/HUB/services/rest/ApplicationService/validateApplicationAndSite",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => "siteAddress={$siteAddress}&applicationName={$appName}&applicationSecret={$appSecret}",
      CURLOPT_HTTPHEADER => array(
        "Content-Type: application/x-www-form-urlencoded",
      ),
    ));
    $response = curl_exec($curl);
    if(curl_exec($curl) === false)
    {
      echo `
        There was an error getting the sideId, please try again.
    `;
    }
    
    curl_close($curl);
    $response = json_decode($response);
    return $response->validateApplicationAndSiteResult->siteId;
}

function getUserTicket($siteId, $appName, $credentialPass, $submissionCert)
{
    $data = array (
        'authenticationRequest' => array (
            'siteId' => $siteId,
            'applicationName' => $appName,
            'credential' => $credentialPass,
            'sessionType' => 'APPLICATION',
            'userDetail' => array ( ),
        ),
    );
    $data_string = json_encode($data);
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/UserTicketInterface/authenticateOrchestrationApplication",
        CURLOPT_HTTPHEADER => array(
          "Content-Type: application/json"
        ),
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 1,
        CURLOPT_FAILONERROR => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data_string,
        CURLOPT_SSLCERT => getcwd() . "cert.p12", 
        CURLOPT_SSLCERTTYPE => "P12",
        CURLOPT_SSLKEYPASSWD => $submissionCert
    ));
    $response = curl_exec($curl);
    $response = json_decode($response);
    if(curl_exec($curl) === false)
    {
      echo `
        There was an error getting the user ticket id, please try again.
      `;
    }
    curl_close($curl);
    return $response->userTicket->id;
}

function generateApplicationTickets ($userTicketId, $appName, $appSecret, $submissionCert) {
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/ApplicationTicketInterface/generateApplicationTickets",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => "applicationName={$appName}&applicationSecret={$appSecret}&noOfTickets=1",
    CURLOPT_HTTPHEADER => array(
      "userTicketId: $userTicketId",
      "Content-Type: application/x-www-form-urlencoded"
    ),
    CURLOPT_SSLCERT => getcwd() . "cert.p12", 
    CURLOPT_SSLCERTTYPE => "P12",
    CURLOPT_SSLKEYPASSWD => $submissionCert
  ));

  $response = curl_exec($curl);
  $response = json_decode($response);
  if(curl_exec($curl) === false)
  {
    echo `
    <div class="alert alert-danger" role="alert">
      There was an error generating the aplication ticket, please try again
    </div>`;
  }
  
  curl_close($curl);
  return $response->applicationTicketCollection->applicationTickets->id;

}

function generateTransmitionId ($applicationTicketId, $submissionCert) {
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/MailitemInterface/startTransmission",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_HTTPHEADER => array(
      "applicationTicketId: $applicationTicketId"
    ),
    CURLOPT_SSLCERT => getcwd() . "cert.p12", 
    CURLOPT_SSLCERTTYPE => "P12",
    CURLOPT_SSLKEYPASSWD => $submissionCert
  ));

  $response = curl_exec($curl);
  if(curl_exec($curl) === false)
  {
    echo `
      <div class="alert alert-danger" role="alert">
        There was an error generating the transmition id
      </div>`;
  }
  
  curl_close($curl);
  return ($response);

}
