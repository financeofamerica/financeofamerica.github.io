<?php
  
  $path = preg_replace('/wp-content(?!.*wp-content).*/','',__DIR__);
  require_once($path.'/wp/wp-load.php');
    
  $appName = get_option('submission_app_name');
  $appSecret = get_option('submission_app_secret');
  $credentialPass = get_option('submission_credential_pass');
  $submissionCert = get_option('submission_cert');
  $siteId =  $_POST['siteId'];
  $tickets =  $_POST['tickets'];

  $data = array (
    'authenticationRequest' => array (
      'siteId' => $siteId,
      'applicationName' => $appName,
      'credential' => $credentialPass,
      'sessionType' => 'APPLICATION',
      'userDetail' => array ( ),
      ),
    );


  $data_string = json_encode($data);
  $curl = curl_init();
  curl_setopt_array($curl, array(
  CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/UserTicketInterface/authenticateOrchestrationApplication",
  CURLOPT_HTTPHEADER => array(
    "Content-Type: application/json"
  ),
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 1,
  CURLOPT_FAILONERROR => true,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $data_string,
  CURLOPT_SSLCERT => "cert.p12", 
  CURLOPT_SSLCERTTYPE => "P12",
  CURLOPT_SSLKEYPASSWD => $submissionCert
  ));
  $response = curl_exec($curl);
  $response = json_decode($response);
  if(curl_exec($curl) === false) {
    echo `There was an error getting the user ticket id, please try again.`;
  }
  curl_close($curl);
  return generateApplicationTickets($response->userTicket->id, $appName, $appSecret, $submissionCert, $tickets);

  function generateApplicationTickets ($userTicketId, $appName, $appSecret, $submissionCert, $tickets) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://awh1-standard-pg1.docvelocity-na8.net/PlatformGateway/services/rest/ApplicationTicketInterface/generateApplicationTickets",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => "applicationName={$appName}&applicationSecret={$appSecret}&noOfTickets={$tickets}",
      CURLOPT_HTTPHEADER => array(
        "userTicketId: $userTicketId",
        "Content-Type: application/x-www-form-urlencoded"
      ),
      CURLOPT_SSLCERT => "cert.p12", 
      CURLOPT_SSLCERTTYPE => "P12",
      CURLOPT_SSLKEYPASSWD => $submissionCert
    ));
      
    $response = curl_exec($curl);
    $response = json_decode($response);
    if(curl_exec($curl) === false) {
      echo `There was an error generating the aplication ticket, please try again`;
    }
        
    curl_close($curl);
    $info = array (
      'applicationTicket' => $response->applicationTicketCollection->applicationTickets,
      'userTicketId' => $userTicketId,
    );
    echo json_encode($info);    
  }