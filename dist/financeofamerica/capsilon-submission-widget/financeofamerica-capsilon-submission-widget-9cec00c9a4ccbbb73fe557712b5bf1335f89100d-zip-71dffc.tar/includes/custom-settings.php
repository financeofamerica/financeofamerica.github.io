<?php

  function so_enqueue_scripts(){

    wp_register_script('ajaxHandle', plugins_url('/partials/js/docs.js', __FILE__), array(), false, true );
    wp_enqueue_script('ajaxHandle' );

    wp_localize_script('ajaxHandle', 'ajax_object', array( 
      'sendDocuments' => ( '/wp-content/plugins/capsilon-submission-widget/includes/submit-docs.php'),
      'siteId' => ( '/wp-content/plugins/capsilon-submission-widget/includes/generate-site-id.php'),
      'userTicket' => ( '/wp-content/plugins/capsilon-submission-widget/includes/generate-user-ticket.php'),
      ));
  }

  function submission_docs_register_settings() {
    add_option( 'submission_docs', 'Documents submission settings');

    add_settings_section("header_section", "Credentials to connect to Capsilon's service", "display_header_options_content", "manage_options");

    add_settings_field("submission_cert", "Capsilon Cert Passphase", "display_cert_input", "manage_options", "header_section");
    add_settings_field("submission_app_name", "Capsilon Application name", "display_app_name", "manage_options", "header_section");
    add_settings_field("submission_site_address", "Capsilon Site Address ", "display_site_address", "manage_options", "header_section");
    add_settings_field("submission_app_secret", "Capsilon Application Secret", "display_app_secret", "manage_options", "header_section");
    add_settings_field("submission_credential_pass", "Capsilon Credential Password", "display_credential_pass", "manage_options", "header_section");

    register_setting('submission_docs_options_group', 'submission_docs', 'submission_docs_callback' );
    register_setting("header_section", "submission_cert");
    register_setting("header_section", "submission_app_name");
    register_setting("header_section", "submission_site_address");
    register_setting("header_section", "submission_app_secret");
    register_setting("header_section", "submission_credential_pass");
  }

  function submission_docs_register_options_page() {
    add_options_page('Documents submission settings', 'Capsilon Documents Submission Plugin', 'manage_options', 'submission_docs', 'submission_options_page');
  }

  function submission_options_page() { 
    ?>
    <div>
      <?php screen_icon(); ?>
        <h1>Documents Submission Plugin Settings</h1>
        <form method="post" action="options.php">
          <?php settings_fields("header_section"); ?>
          <table>
            <?php do_settings_sections("manage_options"); ?>
          </table> 
          <?php  submit_button(); ?>
      </form>
    </div>
    <?php
  }

  function display_header_options_content () {
  }

  function display_cert_input (){ 
    ?>
    <td>
      <input type="password" id="submission_cert" name="submission_cert" value="<?php echo get_option('submission_cert'); ?>" />
    </td>
    <?php
  }

  function display_app_name (){
    ?>
    <td>
      <input type="text" id="submission_app_name" name="submission_app_name" value="<?php echo get_option('submission_app_name'); ?>"/>
    </td>
    <?php
  }

  function display_site_address (){
    ?>
    <td>
      <input type="text" id="submission_site_address" name="submission_site_address" value="<?php echo get_option('submission_site_address'); ?>"/>
    </td>
    <?php
  }

  function display_app_secret() {
    ?>
    <td>
      <input type="password" id="submission_app_secret" name="submission_app_secret" value="<?php echo get_option('submission_app_secret'); ?>"/>
    </td>
    <?php
  }

  function display_credential_pass() {
    ?>
    <td>
      <input type="password" id="submission_credential_pass" name="submission_credential_pass" value="<?php echo get_option('submission_credential_pass'); ?>"/>
    </td>
    <?php
  }

  add_action('admin_menu', 'submission_docs_register_options_page');
  add_action('admin_init', 'submission_docs_register_settings' );
  add_action('wp_enqueue_scripts', 'so_enqueue_scripts' );
?>
