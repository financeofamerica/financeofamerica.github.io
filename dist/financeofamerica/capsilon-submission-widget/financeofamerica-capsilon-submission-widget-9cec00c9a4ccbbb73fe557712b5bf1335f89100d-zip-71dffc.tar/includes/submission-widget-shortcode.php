<?php

function content_form()
{
    ob_start();
    include (plugin_dir_path( __FILE__ ) . 'partials/front/content-form.php');
    return ob_get_clean();
}

add_shortcode('content_form', 'content_form');
