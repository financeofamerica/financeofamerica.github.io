<div id="calculator" class="affordability-calculator breaker-block" ng-app="affordApp">
	<div ng-controller="affordCtrl">
		<div class="container">
			<div class="row">
				<div class="order-2 col-sm-12 order-md-1 col-md-4">
					<label for="annualIncome">Annual income</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" class="form-control" ng-keyup="getAffordability()" ng-model="user.details.annualIncome" name="annualIncome" id="annualIncome" maxlength="30" />
					</div>
					<label for="monthlyDebts">Monthly debts</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.monthlyDebts" name="monthlyDebts" id="monthlyDebts" />
					</div>
					<label for="downPayment">Down payment</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.downPayment" name="downPayment" id="downPayment" />

					</div>
					<div ng-show="!simple">
						<label for="debtToIncome">Debt-to-income</label>
						<div class="input-group mb-3">
							<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.debtToIncome" name="debtToIncome" id="debtToIncome" />
							<div class="input-group-append">
                                <span class="input-group-text">
                                %
                                </span>
							</div>

						</div>
						<label for="interestRate">Interest rate</label>
						<div class="input-group mb-3">
							<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.interestRate" name="interestRate" id="interestRate" />
							<div class="input-group-append">
                                <span class="input-group-text">
                                    %
                                </span>
							</div>
						</div>
						<label for="loanTerm">Loan term</label>
						<div class="input-group mb-3">
							<select type="text" class="selectpicker" ng-init="user.details.loanTerm='30'" ng-change="getAffordability()" ng-model="user.details.loanTerm" name="loanTerm" id="loanTerm" ng-pattern="" required>
								<option value="30">30-year fixed</option>
								<option value="15">15-year fixed</option>
								<option value="5">5/1 ARM</option>
							</select>
						</div>


						<div class="form-inline">
							<div class="input-group mb-3">
								<label class="custom-control fill-checkbox">
									<input type="checkbox" ng-change="getAffordability()" class="fill-control-input" ng-model="user.details.incTaxIns" name="showTaxes" id="incTaxIns" />
									<span class="fill-control-indicator"></span>
									<span class="fill-control-description">Include taxes/ins.</span>
								</label>
							</div>
						</div>
						<div class="form-inline" ng-show="user.details.incTaxIns">
							<label for="taxes">Property tax</label>
							<div class="row">
								<div class="col-md-12">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
                                    <span class="input-group-text">
                                        $
                                    </span>
										</div>
										<input type="text" style="" ng-keyup="getAffordability('ptax')" class="form-control" ng-model="user.details.taxes" name="taxes" id="taxes" maxlength="10" />
										<div class="input-group-append">
											<span class="input-group-text">/year</span>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="input-group mb-3">
										<input type="text" style="margin-left:1%;" ng-keyup="getAffordability('ptaxpercent')" class="form-control" ng-model="user.details.taxPercent" name="taxPercent" id="taxPercent" maxlength="5" />
										<div class="input-group-append">
                                    <span class="input-group-text">
                                        %
                                    </span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div ng-show="user.details.incTaxIns">
							<label for="homeInsurance">Home insurance</label>
							<div class="input-group mb-3">
								<div class="input-group-prepend">
                                    <span class="input-group-text">
                                        $
                                    </span>
								</div>
								<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.homeInsurance" name="homeInsurance" id="homeInsurance" />
								<div class="input-group-append">
                                    <span class="input-group-text">
                                        /year
                                    </span>
								</div>
							</div>
						</div>
						<div class="form-inline" ng-show="user.details.incTaxIns">
							<div class="input-group mb-3">
								<label class="custom-control fill-checkbox mb-3">
									<input type="checkbox" class="fill-control-input" ng-change="getAffordability()" ng-model="user.details.incPMI" name="incPMI" id="incPMI" />
									<span class="fill-control-indicator"></span>
									<span class="fill-control-description">Include PMI.</span>
								</label>
							</div>
						</div>
						<label for="hoaDues">HOA dues</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
                                <span class="input-group-text">
                                    $
                                </span>
							</div>
							<input type="text" ng-keyup="getAffordability()" class="form-control" ng-model="user.details.hoaDues" name="hoaDues" id="hoaDues" />
							<div class="input-group-append">
                                <span class="input-group-text">
                                    /month
                                </span>
							</div>

						</div>
					</div>
					<div class="simple" ng-show="simple">
						<a href="" ng-click="simple = false">Advanced<span class="fa fa-chevron-down"></span></a>
					</div>
					<div class="simple" ng-show="!simple">
						<a href="" ng-click="simple = true">Simple<span class="fa fa-chevron-up"></span></a>
					</div>
				</div>
				<div class="order-1 col-sm-12 order-md-2 col-md-8 display" style="margin-bottom: 20px;">
					<h5>You can afford a house up to</h5>
					<div class="affordable-number">
						{{user.details.affordableValue  | currency:undefined:0}}
					</div>
					<div class="affordable-txt">
						<span ng-show="user.details.debtToIncome <= 36">Based on your income, a house at this price should fit comfortably within your budget.</span>
						<span ng-show="user.details.debtToIncome > 36">Based on your income, a house at this price may stretch your budget too thin.</span>
					</div>

					<div class="image-wrapper">
						<img class="graphic-piggy" src="<?php echo plugins_url( '../assets/src/images/piggy.svg', __FILE__ ) ?>" ng-style="{'width' : imgSize('pig'), 'height' : imgSize('pig')}">
						<div class="payment label" ng-class="user.details.debtToIncome <= 36 ? 'label-success':'label-warning'">{{user.details.payment | currency:undefined:0}}/mo</div>
						<img class="graphic-house" src="<?php echo plugins_url( '../assets/src/images/house.svg', __FILE__ ) ?>" ng-style="{'width' : imgSize('house'), 'height' : imgSize('house')}">
					</div>
					<div>
						<input type="range" ng-class="user.details.debtToIncome > 36 ? 'warning':''"  ng-change="getAffordability('slider')" ng-model="user.details.debtToIncome" class="form-control-range range" min="0" step="1" max="43" />
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


