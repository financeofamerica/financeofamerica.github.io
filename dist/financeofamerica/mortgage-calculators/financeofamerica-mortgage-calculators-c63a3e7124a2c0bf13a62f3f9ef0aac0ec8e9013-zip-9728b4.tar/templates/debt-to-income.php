<div id="calculator" class="breaker-block debt-to-income-calculator" ng-app="debtToIncomeApp">
	<div ng-controller="PieCtrl">
		<div class="container">
			<div class="row">
				<div class="col-sm-5 col-md-4">
					<h3>
						Debt-to-income ratio:<span class="ratio" ng-class="{'ratio-red':ratio>50}">
                                {{ratio | number:0}}%
                            </span>
					</h3>
					<label for="annualIncome">Annual income</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" class="form-control" ng-keyup="getRatio()" ng-model="user.details.annualIncome" name="annualIncome" id="annualIncome" maxlength="30" />
					</div>
					<label for="minCreditPayments">Min. credit card payments</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" ng-keyup="getRatio()" class="form-control " ng-model="user.details.minCreditPayments" name="minCreditPayments" id="minCreditPayments" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                /mo
                            </span>
						</div>
					</div>
					<label for="carLoanPayments">Car loan payments</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" ng-keyup="getRatio()" class="form-control" ng-model="user.details.carLoanPayments" name="carLoanPayments" id="carLoanPayments" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                /mo
                            </span>
						</div>
					</div>
					<label for="otherPayments">Other loan obligations</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" ng-keyup="getRatio()" class="form-control" ng-model="user.details.otherPayments" name="otherPayments" id="otherPayments" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                /mo
                            </span>
						</div>
					</div>
				</div>
				<div class="col-sm-7 col-md-8">
					<h2>Estimated home loan eligibility</h2>
					<div class="row">
						<div class="col-md-6">
							<canvas role="img" aria-label="This chart contains data that is also available in the following amortization schedule breakdown table." id="pie" style="margin:0 auto;" height="300" width="300" class="chart chart-pie" chart-data="data" chart-labels="labels">
							</canvas>
						</div>
						<div class="col-md-6">
							<table class="table">
								<thead>
								<tr class="dti">

									<th ng-if="ratio<20"><span style="font-weight: bold">Your DTI is very good.</span> Having a DTI ratio of 36% or less is considered ideal, and anything under 20% is excellent.</th>
									<th ng-if="ratio>21 && ratio<36"><span style="font-weight: bold">Your DTI is good.</span> Having a DTI ratio of 36% or less is considered ideal.</th>
									<th ng-if="ratio>36 && ratio<50"><span style="font-weight: bold">Your DTI is OK.</span> It's under the 50% limit, but having a DTI ratio of 36% or less is considered ideal. Paying down debt or increasing your income can help improve your DTI ratio.</th>
									<th ng-if="ratio>50"><span style="font-weight: bold; color:#ff0000">Your DTI is over the limit.</span> In most cases, 50% is the highest debt-to-income that lenders will allow. Paying down debt or increasing your income can improve your DTI ratio.</th>
								</tr>
								</thead>
								<tbody>
								<tr>
									<td>
										<div class="circle circle1"></div>Remaining</td>
									<td>{{remaining | currency:undefined:0}}</td>
								</tr>
								<tr>
									<td>
										<div class="circle circle2"></div>Total monthly debts</td>
									<td>{{totalDebt | currency:undefined:0}}</td>
								</tr>
								<tr>
									<td>
										<div class="circle circle3"></div>Max estimated mortgage payment</td>
									<td>{{maxPayment | currency:undefined:0}}</td>
								</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>