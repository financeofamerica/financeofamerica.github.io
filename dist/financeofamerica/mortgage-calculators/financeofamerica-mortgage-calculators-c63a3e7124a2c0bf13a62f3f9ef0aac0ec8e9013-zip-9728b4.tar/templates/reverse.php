<?php
                    
function loadReverse() {
    $age = "";
    $companyName = get_option( 'mc-company-name', "Finance of America");
    if (empty($companyName)) {
        $companyName = "Finance of America";
    }
    for ($i = 62; $i < 100; $i++) {
        $age .= "<option title='{$i}' value='{$i}'>{$i}</option>" . PHP_EOL;
    }

    $path = admin_url( 'admin-ajax.php', 'relative' );

    $result = <<<REVCALC
<div id="calculator" class="reverse-calculator breaker-block">
    <div class="container">
		<div id="reverse-holder" class="row">
			<div id="reverse-form" class="col-sm-12 col-md-3">
				<label for="age">Age</label>
                <div class="input-group mb-3 select-wrapper">
                <span aria-hidden="true"><i class="arrow-down-icon"></i></span>
					<select id="age" name="age">
                        {$age}
						<option title="100" value="100">100+</option>
					</select>
				</div>
				<label for="home_value">Home Value</label>
				<div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text">
							$
						</span>
					</div>
					<input class="form-control" type="text" name="home_value" id="home_value" value="425000">
				</div>
				<label for="mortgage_balance">Mortgage Balance</label>
				<div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text">
							$
						</span>
					</div>
					<input class="form-control" type="text" name="mortgage_balance" id="mortgage_balance" value="100000">
				</div>
				<label for="state">State</label>
                <div class="input-group mb-3 select-wrapper">
                <span aria-hidden="true"><i class="arrow-down-icon"></i></span>
					<select id="state" name="state">
						<option value="AL">Alabama</option>
						<option value="AK">Alaska</option>
						<option value="AZ">Arizona</option>
						<option value="AR">Arkansas</option>
						<option value="CA">California</option>
						<option value="CO">Colorado</option>
						<option value="CT">Connecticut</option>
						<option value="DE">Delaware</option>
						<option value="DC">District Of Columbia</option>
						<option value="FL">Florida</option>
						<option value="GA">Georgia</option>
						<option value="HI">Hawaii</option>
						<option value="ID">Idaho</option>
						<option value="IL">Illinois</option>
						<option value="IN">Indiana</option>
						<option value="IA">Iowa</option>
						<option value="KS">Kansas</option>
						<option value="KY">Kentucky</option>
						<option value="LA">Louisiana</option>
						<option value="ME">Maine</option>
						<option value="MD">Maryland</option>
						<option value="MA">Massachusetts</option>
						<option value="MI">Michigan</option>
						<option value="MN">Minnesota</option>
						<option value="MS">Mississippi</option>
						<option value="MO">Missouri</option>
						<option value="MT">Montana</option>
						<option value="NE">Nebraska</option>
						<option value="NV">Nevada</option>
						<option value="NH">New Hampshire</option>
						<option value="NJ">New Jersey</option>
						<option value="NM">New Mexico</option>
						<option value="NY">New York</option>
						<option value="NC">North Carolina</option>
						<option value="ND">North Dakota</option>
						<option value="OH">Ohio</option>
						<option value="OK">Oklahoma</option>
						<option value="OR">Oregon</option>
						<option value="PA">Pennsylvania</option>
						<option value="RI">Rhode Island</option>
						<option value="SC">South Carolina</option>
						<option value="SD">South Dakota</option>
						<option value="TN">Tennessee</option>
						<option value="TX">Texas</option>
						<option value="UT">Utah</option>
						<option value="VT">Vermont</option>
						<option value="VA">Virginia</option>
						<option value="WA">Washington</option>
						<option value="WV">West Virginia</option>
						<option value="WI">Wisconsin</option>
						<option value="WY">Wyoming</option>
					</select>
				</div>
            </div>
            <div id="calc-result" class="col-sm-12 col-md-9">
                <div class="row">
                    <div id="hecm-holder" class="col-sm-12 col-md-6">
                        <h3 class="center">HECM</h3>
                        <div id="hecm-wrapper" class="doughnut">
                            <div class="payment-wrapper">
                                <span class="chart-type"></span>
                                <span id="HECMtext" class="payment-txt">Total Proceeds</span>
                                <span id="HECMproceeds" class="payment"></span>
                            </div>
                            <div class="chart-container">
                                <canvas role="img" aria-label="This chart contains data that is also available in the following amortization schedule breakdown table." id="HECMChart"></canvas>
                            </div>
                            <div class="legend">
                                <ul class="color-codes">
                                    <li class="nodisc">
                                        <div class="color-code color1"></div>
                                        <span class="labels">Mortgage Payoff</span>:
                                        <span class="values" id="HECMpayoff"></span>
                                    </li>
                                    <li class="nodisc">
                                        <div class="color-code color2"></div>
                                        <span class="labels" id="HECMlabel">Available Proceeds</span>:
                                        <span class="values" id="HECMfunds"></span>
                                    </li>
                                    <li class="nodisc">
                                        <div class="color-code color3"></div>
                                        <span class="labels">Remaining Equity</span>:
                                        <span class="values" id="HECMequity"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div id="homesafe-holder" class="col-sm-12 col-md-6">
                        <h3 class="center">HomeSafe&reg;</h3>
                        <div id="homesafe-invalid" class="warning">
                            {$companyName} does NOT currently offer 
                            HomeSafe&reg; in <span id="property-state"></span>.
                        </div>
                        <div id="homesafe-wrapper" class="doughnut">
                            <div class="payment-wrapper">
                                <span class="chart-type"></span>
                                <span id="HStext" class="payment-txt">Total Proceeds</span>
                                <span id="HSproceeds" class="payment"></span>
                            </div>
                            <div class="chart-container">
                                <canvas id="HSChart"></canvas>
                            </div>
                            <div class="legend">
                                <ul class="color-codes">
                                    <li class="nodisc">
                                        <div class="color-code color1"></div>
                                        <span class="labels">Mortgage Payoff</span>:
                                        <span class="values" id="HSpayoff"></span>
                                    </li>
                                    <li class="nodisc">
                                        <div class="color-code color2"></div>
                                        <span class="labels" id="HSlabel">Available Proceeds</span>:
                                        <span class="values" id="HSfunds"></span>
                                    </li>
                                    <li class="nodisc">
                                        <div class="color-code color3"></div>
                                        <span class="labels">Remaining Equity</span>:
                                        <span class="values" id="HSequity"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
		
        <div id="error_message" class="col-md-12">
            <p>* Available proceeds is negative because you many need to bring this much cash to close.</p>
            <p>It looks like you may need to bring cash to close, but a Reverse Mortgage may still be beneficial depending on your unique situation.</p>
            <p>Please call <a href="tel:1-{$phone}">{$phone}</a></p>
        </div>

        <div class="col-md-12">
            <div class="disclaimer">
                <p id="loan_calculator_disclaimer">
                    The illustration and figures above are an estimate based on the value and age you provided. This is the amount you may be eligible for before fees. It is not a loan commitment and does not mean you have been approved. All borrower’s must meet all loan obligations, including living in the property as the principal residence and paying all property charged, including property taxes, fees, and hazard insurance. The borrower must maintain the home. If the borrower does not meet the loan obligations the loan could be called due.
                </p>
            </div>
        </div>
        
    </div>
</div>
REVCALC;

    return $result;
}

?>