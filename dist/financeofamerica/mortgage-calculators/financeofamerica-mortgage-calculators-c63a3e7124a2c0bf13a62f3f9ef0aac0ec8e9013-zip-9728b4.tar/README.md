# Mortgage Calculators

## Description

Wordpress Mortgage Calculators

## Usage
Shortcode [mortgage-calculator type="reverse"]

## Changelog

### 1.0.0

* Initial commit.

## Contributors

* FoA Marketing Technology Team

## License

Licensed under [GPL v3](https://opensource.org/licenses/GPL-3.0).
