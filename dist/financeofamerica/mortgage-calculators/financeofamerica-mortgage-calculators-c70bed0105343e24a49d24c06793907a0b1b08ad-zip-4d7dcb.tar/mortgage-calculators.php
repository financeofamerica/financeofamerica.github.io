<?php
/**
 * Plugin Name:       Mortgage Calculators
 * Description:       Implement mortgage calculators
 * Version:           1.0.9
 * Author:            Andrew Karch, Nikun Patel, Chris Carrel
 * Author URI:        https://www.financeofamerica.com
 */
 

 
class mortgage_calcs {
	private $version;

	public function __construct() {
		self::includes();
		self::hooks();
	}
	
	private static function includes() {
		require_once dirname( __FILE__ ) . '/admin/mc-config-options.php';

		require_once dirname( __FILE__ ) . '/fields/class-gf-mortgage-calc.php';
		require_once dirname( __FILE__ ) . '/fields/class-gf-reverse-calc.php';
	}

	private static function hooks() {
		add_action( 'wp_enqueue_scripts', array(__CLASS__, 'add_styles'), 12);

		// add_filter( "plugin_action_links_$plugin", 'loan_calculator_add_settings_link' );
		add_action( 'wp_ajax_loan_calc_action', array( __CLASS__, 'reverse_calc_action') );
		add_action( 'wp_ajax_nopriv_loan_calc_action', array( __CLASS__, 'reverse_calc_action') );
		add_shortcode( 'mortgage_calculator', array(__CLASS__, 'show_calc' ));
	}

	public static function add_styles() {
		$plugin_data = get_plugin_data( __FILE__ );
		$v = $plugin_data['Version'];	

		$current_theme = wp_get_theme();

		global $wp_styles;
		$srcs = array_map('basename', (array) wp_list_pluck($wp_styles->registered, 'src') );

		$addBootstrap = ( (!in_array('bootstrap.css',$srcs) && !in_array('bootstrap.min.css',$srcs) && ($current_theme['Template'] != 'understrap')) && get_option( 'mc-load-bootstrap', 0));
		$addBootSelect = ( (!in_array('bootstrap-select.css',$srcs) && !in_array('bootstrap-select.min.css',$srcs) && ($current_theme != 'FOA Theme')) && get_option( 'mc-load-bootstrap-select', 0));

		if ($addBootstrap) {
			wp_enqueue_script( 'bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js');
			wp_enqueue_style( 'bootstrap', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css');
		}
		if ($addBootSelect) {
			wp_enqueue_script( 'bootstrap-select', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.10/js/bootstrap-select.min.js');
			wp_enqueue_style( 'bootstrap-select', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.10/css/bootstrap-select.min.css');
		}

		$addChartJS = ( !in_array('Chart.css',$srcs) && !in_array('Chart.min.css',$srcs));
		$addFormsStyles = (($current_theme != 'FOA Theme'));
		if ($addFormsStyles) {
			wp_enqueue_style( 'form-styles', plugins_url( 'assets/dist/css/form-styles.css', __FILE__ ), array(), $v );
		}
		if ($addChartJS) {
			wp_enqueue_script( 'chartjs', plugins_url( 'assets/dist/js/Chart.min.js', __FILE__ ), array('jquery'), $v );
			wp_enqueue_style( 'chartjs', plugins_url( 'assets/dist/css/Chart.min.css', __FILE__ ), array(), $v );
		}
		
		// wp_enqueue_script( 'html2canvas', plugins_url( 'assets/dist/js/html2canvas.min.js', __FILE__ ), array(), '1.0.0-r1', true);
		wp_enqueue_style( 'mortgagecalc', plugins_url( 'assets/dist/css/calculator.min.css', __FILE__ ), array(), $v );
		wp_enqueue_script( 'mortgagecalc', plugins_url( 'assets/dist/js/mc-bundle.min.js', __FILE__ ), array(), $v, true);
		
		wp_localize_script( 'mortgagecalc', 'ajaxObj',
			array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
	}

	public static function show_calc( $atts ) {
		$atts = shortcode_atts( array(
			'type' => 'affordability'
		), $atts, 'mortgage_calculator' );
	
		$calcString = "Show the Calculator";
		
		switch ($atts['type'])  {
		case "reverse":
			require_once dirname( __FILE__ ) . '/templates/reverse.php';
			$calcString = loadReverse();
			break;
		case "mortgage":
			ob_start();
			wp_enqueue_script('js', plugin_dir_url(__FILE__) . 'assets/dist/js/mortgage-calc.js');
			require_once dirname( __FILE__ ) . '/templates/mortgage.php';
			$clean = ob_get_clean();
			return $clean;
			break;
		case "affordability":
			ob_start();
			wp_enqueue_script('js', plugin_dir_url(__FILE__) . 'assets/dist/js/affordability-calc.js');
			require_once dirname( __FILE__ ) . '/templates/affordability.php';
			$clean = ob_get_clean();
			return $clean;
			break;
		case "refinance":
			ob_start();
			wp_enqueue_script('js', plugin_dir_url(__FILE__) . 'assets/dist/js/refinance-calc.js');
			require_once dirname( __FILE__ ) . '/templates/refinance.php';
			$clean = ob_get_clean();
			return $clean;
			break;
		case "debt-to-income":
			ob_start();
			wp_enqueue_script('js', plugin_dir_url(__FILE__) . 'assets/dist/js/debt-to-income-calc.js');
			require_once dirname( __FILE__ ) . '/templates/debt-to-income.php';
			$clean = ob_get_clean();
			return $clean;
			break;
		case "amortization":
			ob_start();
			wp_enqueue_script('js', plugin_dir_url(__FILE__) . 'assets/dist/js/amortization-calc.js');
			require_once dirname( __FILE__ ) . '/templates/amortization.php';
			$clean = ob_get_clean();
			return $clean;
			break;
		default:
			$calcString = "DEFAULT CALC";
		}
		
		return $calcString;
	}

	public function reverse_calc_action() {

		$HECMmax = get_option( 'mc-hecm-max', 679650);
		$HECMmaxProceeds = get_option( 'mc-hecm-max-proceeds', 679650);
		$HECMrate = get_option( 'mc-hecm-rate', "0" ); // TODO: Load the rate from the settings
		$HSmax = get_option( 'mc-homesafe-max', 600000);
		$HSmaxProceeds = get_option( 'mc-homesafe-max-proceeds', 4000000);
		$HSrate = get_option( 'mc-homesafe-rate', "0" ); // TODO: Load the rate from the settings
		$HSstates = get_option( 'mc-homesafe-states', array() );
	
		$age = filter_var($_POST['age'], FILTER_SANITIZE_NUMBER_INT);
		$state = strtoupper(substr(filter_var($_POST['state'], FILTER_SANITIZE_STRING),0,2));
		$homeVal = filter_var($_POST['home_value'], FILTER_SANITIZE_NUMBER_INT);
		$mtgVal = filter_var($_POST['mortgage_balance'], FILTER_SANITIZE_NUMBER_INT);
		
		$request = array( 'age' => $age, 'location' => $state, 'homevalue' => $homeVal, 'current_mortgage' => $mtgVal);

		$HECMplf = ($HECMrate == "0") ? array($age => "0") : json_decode($HECMrate,true);
		$HSplf = ($HSrate == "0") ? array($age => "0") : json_decode($HSrate,true);
	
		$HECM_homeVal = ($homeVal > $HECMmax) ? $HECMmax : $homeVal;
		$HS_homeVal = 'invalid';
		if (in_array($state, $HSstates)) {
			$HS_homeVal = ($homeVal <= $HSmax) ? $homeVal : $HSmax + ( 0.75 * ($homeVal-$HSmax));
		} 
		
		// $HECMProceeds = $HECM_home_value * doubleval($HECMplf) - ($HECM_home_value * 0.02) - 2500;
		$HECMproceeds = intval($HECM_homeVal * doubleval($HECMplf[$age]['plf']));
		$HECMproceeds = ($HECMproceeds <= $HECMmaxProceeds) ? $HECMproceeds : $HECMmaxProceeds;
		$HECM = array('proceeds' => $HECMproceeds, 'payoff' => $mtgVal, 'funds' => $HECMproceeds - $mtgVal, 'equity' => $homeVal - $HECMproceeds );

		// $HomeSafeResult = $HomeSafeHomeValue * doubleval($Homesafeplf/100) - ($HomeSafeHomeValue * 0.02) - 2500;
		if ($HS_homeVal != 'invalid') {
			$HSproceeds = intval($HS_homeVal * doubleval($HSplf[$age]['plf']));
			$HSproceeds = ($HSproceeds <= $HSmaxProceeds) ? $HSproceeds : $HSmaxProceeds;
			$HS = array('proceeds' => (int)$HSproceeds, 'payoff' => $mtgVal, 'funds' => $HSproceeds - $mtgVal, 'equity' => $homeVal - $HSproceeds );
		} else {
			$HS = array('proceeds' => 'invalid');
		}

		$return = array(
			'Input' => $request,
			'HECM' => $HECM,
			'HomeSafe' => $HS
		);
	
		echo json_encode($return);
		
		wp_die(); // this is required to terminate immediately and return a proper response
	}
}

 
new mortgage_calcs();
