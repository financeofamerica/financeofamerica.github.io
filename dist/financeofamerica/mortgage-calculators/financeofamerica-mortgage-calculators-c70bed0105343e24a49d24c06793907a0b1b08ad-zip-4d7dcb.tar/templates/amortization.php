<div id="calculator" class="amortization-calculator breaker-block" ng-app="amortizationCalcApp">
	<div ng-controller="LineCtrl">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div>
						<h2>Over {{user.details.loanTerm == "15"? "15":"30"}} years you'll pay: <span style="color:#1a73e0" ng-bind="totalPayment | currency:undefined:0"></span></h2>
					</div>
					<div>
						<h3>Based on an estimated monthly payment of <span ng-bind="info.paymentAmt | currency:undefined:0"></span></h3>
					</div>
				</div>
			</div>
			<div class="row justify-content-between">
				<div class="order-2 col-sm-12 order-md-1 col-md-5">
					<label for="loanAmount">Loan amount</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="number" class="form-control " ng-keyup="calculate()" ng-model="user.details.loanAmount" name="loanAmount" id="loanAmount" maxlength="30" />
					</div>
					<label for="currentTerm">Loan term</label>
					<div class="input-group mb-3">
						<select ng-change="calculate('term')" class="selectpicker" ng-init="user.details.loanTerm='30'" ng-model="user.details.loanTerm" name="loanTerm" id="loanTerm">
							<option value="30">30 Year Fixed</option>
							<option value="15">15 Year Fixed</option>
							<option value="5">5/1 ARM</option>
						</select>
					</div>
					<label for="interestRate">Interest rate</label>
					<div class="input-group mb-3">
						<input type="number" class="form-control" ng-keyup="calculate()" ng-model="user.details.interestRate" name="interestRate" id="interestRate" maxlength="10" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                %
                            </span>
						</div>
					</div>
					<label for="loanAmount">Add Extra Monthly Payment:</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="number" class="form-control " ng-keyup="calculate()" ng-model="user.details.addMoPayment" name="addPayment" id="addPayment" maxlength="30" />
					</div>
					<label for="origYear">Start Date</label>
					<div class="input-group mb-3">
						<select class="selectpicker month-select-special" ng-model="user.details.startMonth">
							<option value="0">Jan</option>
							<option value="1">Feb</option>
							<option value="2">Mar</option>
							<option value="3">Apr</option>
							<option value="4">May</option>
							<option value="5">Jun</option>
							<option value="6">Jul</option>
							<option value="7">Aug</option>
							<option value="8">Sep</option>
							<option value="9">Oct</option>
							<option value="10">Nov</option>
							<option value="11">Dec</option>
						</select>
					</div>
				</div>
				<div class="order-1 col-sm-12 order-md-2 col-md-6">
					<div class="chart-wrapper">
						<canvas class="chart chart-line ng-isolate-scope" chart-data="data" chart-labels="labels" chart-click="onClick" chart-hover="onHover" chart-series="series" chart-options="options" chart-dataset-override="datasetOverride" chart-colors="colors" width="500" height="500"> </canvas>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<h2 style="margin:0 0 10px">
						Amortization schedule breakdown
					</h2>
					<div>
						Total principal payments: <span ng-bind="user.details.loanAmount | currency:undefined:0"></span>
					</div>
					<div style="margin-bottom: 15px;">
						Total interest payments: <span ng-bind="totalInterest | currency:undefined:0"></span>
					</div>
					<table class="table">
						<thead>
						<th>DATE</th>
						<th>AMOUNT</th>
						<th>INTEREST</th>
						<th>PRINCIPAL</th>
						<th>BALANCE</th>
						</thead>
						<tbody>
						<tr ng-repeat="item in payments | limitTo: limit">
							<td ng-bind="getdate(item.month)"></td>
							<td ng-bind="item.amount | currency:undefined:0"></td>
							<td ng-bind="item.interest | currency:undefined:0"></td>
							<td ng-bind="item.principal | currency:undefined:0"></td>
							<td ng-bind="item.balance | currency:undefined:0"></td>
						</tr>
						</tbody>
					</table>

					<div class="simple" ng-show="limit === 5">
						<a href="" ng-click="showMore()">Show More<span class="fa fa-chevron-down"></span></a>
					</div>
					<div class="simple"  ng-show="limit > 5">
						<a href=""  ng-click="showLess()">Show Less <span class="fa fa-chevron-up"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>