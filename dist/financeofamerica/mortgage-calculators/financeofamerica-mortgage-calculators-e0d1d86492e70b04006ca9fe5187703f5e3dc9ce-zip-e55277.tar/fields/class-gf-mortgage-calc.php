<?php

if ( class_exists( 'GFForms' ) ) {

class GFA_Field_MortgageCalc extends GF_Field {

	public $type = 'foa_mortgage_calc';

    public function __construct( $data = array() ) {
		// $data['visibility'] = 'visible';
		parent::__construct($data);
    }
	
	/**
     * Adds the field button to the specified group.
     *
     * @param array $field_groups The field groups containing the individual field buttons.
     *
     * @return array
     */
    public function add_button( $field_groups ) {
        $field_groups = $this->maybe_add_field_group( $field_groups );
    
        return parent::add_button( $field_groups );
	}
	
    /**
	 * Adds the custom field group if it doesn't already exist.
	 *
	 * @param array $field_groups The field groups containing the individual field buttons.
	 *
	 * @return array
	 */
	public function maybe_add_field_group( $field_groups ) {
		foreach ( $field_groups as $field_group ) {
			if ( $field_group['name'] == 'gfa_calculators' ) {
	
				return $field_groups;
			}
		}
	
		$field_groups[] = array(
			'name'   => 'gfa_calculators',
			'label'  => __( 'Calculators', 'gfaddons' ),
			'fields' => array()
		);
	
		return $field_groups;
	}

	public function get_form_editor_button()
	{
        return array(
            'group' => 'gfa_calculators',
            'text'  => $this->get_form_editor_field_title()
        );
	}

	/**
	 * Indicate if this field type can be used when configuring conditional logic rules.
	 *
	 * @since 2.4
	 *
	 * @return bool
	 */
	public function is_conditional_logic_supported() {
		return true;
	}

	public function get_form_editor_field_title() {
		return esc_attr__( 'Mortgage Calc', 'gfaddons' );
	}

	function get_form_editor_field_settings() {
		return array(
			'conditional_logic_field_setting',
			'label_setting',
		);
	}

	public function get_form_editor_inline_script_on_page_render() {
		return "
		gform.addFilter('gform_form_editor_can_field_be_added', function (canFieldBeAdded, type) {
					if (type == '" . $this->type . "') {
						if (GetFieldsByType(['" . $this->type . "']).length > 0) {
								alert(" . json_encode( esc_html__( 'SORRY! Only one ', 'gfcampaign' ) . $this->get_form_editor_field_title() . esc_html__(' Field Allowed', 'gfcampaign' ) ) . ");
								return false;
						}
					}
				return canFieldBeAdded;
		});" . PHP_EOL . sprintf( "function SetDefaultValues_%s(field) {field.label = '%s';}", $this->type, $this->get_form_editor_field_title() ) . PHP_EOL;
	}

	public function get_field_input( $form, $value = '', $entry = null ) {

		$is_entry_detail = $this->is_entry_detail();
		$is_form_editor  = $this->is_form_editor();

		$content = $is_entry_detail || $is_form_editor ? "<div class='gf-html-container'><span class='gf_blockheader'>
															<i class='fa fa-code fa-lg'></i> " . esc_html__( 'Mortgage Calculator', 'gravityforms' ) .
															'</span><span>' . esc_html__( '', 'gravityforms' ) . '</span></div>'
														: $this->content;
		$content = GFCommon::replace_variables_prepopulate( $content ); // adding support for merge tags

		// adding support for shortcodes
		$content = $this->do_shortcode( $content );

		return $content;
	}

	public function get_field_content( $value, $force_frontend_label, $form ) {
		$form_id         = $form['id'];
		$admin_buttons   = $this->get_admin_buttons();
		$is_entry_detail = $this->is_entry_detail();
		$is_form_editor  = $this->is_form_editor();
		$is_admin        = $is_entry_detail || $is_form_editor;
		$field_label     = $this->get_field_label( $force_frontend_label, $value );
		$field_id        = $is_admin || $form_id == 0 ? "input_{$this->id}" : 'input_' . $form_id . "_{$this->id}";
		$field_content   = ! $is_admin ? '{FIELD}' : $field_content = sprintf( "%s<label class='gfield_label' for='%s'>%s</label>{FIELD}", $admin_buttons, $field_id, esc_html( $field_label ) );

		return $field_content;
	}

	public function sanitize_settings() {
		parent::sanitize_settings();
		$this->content = GFCommon::maybe_wp_kses( $this->content );
	}

	public function do_shortcode( $content ){

		if( isset($GLOBALS['wp_embed']) ) {
			// adds support for the [embed] shortcode
			$content = $GLOBALS['wp_embed']->run_shortcode( $content );
		}
		// executes all other shortcodes
		$content = do_shortcode( $content );

		return $content;
	}
}

}