<div id="calculator" class="refinance-calculator breaker-block" ng-app="refinanceCalcApp">
	<div ng-controller="BarCtrl">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<label for="currentLoan">Current loan amount</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" class="form-control" ng-keyup="calculate('loanAmount')" ng-model="user.details.currentLoan" name="currentLoan" id="currentLoan" maxlength="30" />
					</div>
					<label for="interescurrenttermtRate">Interest rate</label>
					<div class="input-group mb-3">
						<input type="text" class="form-control" ng-keyup="calculate('rate')" ng-model="user.details.interestRate" name="interestRate" id="interescurrenttermtRate" maxlength="10" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                %
                            </span>
						</div>
					</div>
					<label for="currentTerm">Current term</label>
					<div class="input-group mb-3">
						<input type="text" ng-keyup="calculate('dpayment')" class="form-control" ng-model="user.details.currentTerm" name="currentTerm" id="currentTerm" maxlength="30" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                years
                            </span>
						</div>
					</div>
					<label for="origYear">Origination year</label>
					<div class="input-group">
						<input type="text" class="form-control" ng-keyup="calculate('origYear')" ng-model="user.details.origYear" name="origYear" id="origYear" maxlength="30" />
					</div>
					<label for="newLoan">New loan amount</label>
					<div class="input-group mb-3">
						<div class="input-group-prepend">
                            <span class="input-group-text">
                                $
                            </span>
						</div>
						<input type="text" class="form-control" ng-keyup="calculate('loanAmount')" ng-model="user.details.newLoan" name="newLoan" id="newLoan" maxlength="30" />
					</div>
					<label for="newinterestRate">New interest rate</label>
					<div class="input-group mb-3">
						<input type="text" class="form-control" ng-keyup="calculate('rate')" ng-model="user.details.newinterestRate" name="newinterestRate" id="newinterestRate" maxlength="10" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                %
                            </span>
						</div>
					</div>
					<label for="newTerm">New term</label>
					<div class="input-group">
						<input type="text" ng-keyup="calculate('dpayment')" class="form-control" ng-model="user.details.newTerm" name="newTerm" id="newTerm" maxlength="30" />
						<div class="input-group-append">
                            <span class="input-group-text">
                                years
                            </span>
						</div>
					</div>
					<div class="form-group">
						<label for="refiFees">Refinance fees</label>
						<div class="input-group">
							<div class="input-group-prepend">
                                <span class="input-group-text">
                                    $
                                </span>
							</div>
							<input type="text" class="form-control" ng-keyup="calculate('loanAmount')" ng-model="user.details.refiFees" name="refiFees" id="refiFees" maxlength="30" />
						</div>
					</div>
					<div ng-show="!simple">
						<div class="form-group">
							<label for="cashOut">Cash out</label>
							<div class="input-group mb-3">
								<div class="input-group-prepend">
                                    <span class="input-group-text">
                                        $
                                    </span>
								</div>
								<input type="text" class="form-control" ng-keyup="calculate('')" ng-model="user.details.cashOut" name="cashOut" id="cashOut" maxlength="30" />
							</div>
						</div>
						<div class="form-inline">
							<label class="custom-control fill-checkbox mb-3">
								<input type="checkbox" ng-click="calculate('')" class="fill-control-input" ng-model="user.details.addFeeinNewloan" name="addFeeinNewloan" id="addFeeinNewloan" />
								<span class="fill-control-indicator"></span>
								<span class="fill-control-description">Roll fees into new loan</span>
							</label>
						</div>
					</div>
					<div class="simple" ng-show="simple">
						<a href="" ng-click="simple = false">Advanced<span aria-hidden="true"><i class="fa fa-chevron-down"></i></span></a>
					</div>
					<div class="simple" ng-show="!simple">
						<a href="" ng-click="simple = true">Simple<span aria-hidden="true"><i class="fa fa-chevron-up"></i></span></a>
					</div>
				</div>
				<div class="col-sm-12 col-md-6">
					<div class="chart-wrapper">
						<div class="payment-wrapper">
							<span class="payment-txt">Refinancing could save you</span>
							<span class="payment">{{user.details.refiSavings|currency:undefined:0}} /mo</span>
						</div>
						<canvas role="img" aria-label="This chart contains data that is also available in the following amortization schedule breakdown table." id="bar" class="chart chart-bar" chart-data="data" chart-colors="colors" chart-labels="labels"></canvas>
						<ul class="color-codes">
							<li>
								<span class="labels">MONTHLY SAVINGS</span>:
								<span class="values">{{user.details.refiSavings|currency:undefined:0}}/mo</span>
							</li>
							<li>
								<span class="labels">NEW PAYMENT</span>:
								<span class="values">{{user.details.newPayment|currency:undefined:0}}</span>
							</li>
							<li>
								<span class="labels">BREAK EVEN</span>:
								<span class="values">{{user.details.breakEven}} months</span>
							</li>
							<li>
								<div class="color-code color1"></div>
								<span class="labels">COSTS</span>:
								<span class="values">{{user.details.refiFees|currency:undefined:0}}</span>
							</li>
							<li>
								<div class="color-code color2"></div>
								<span class="labels">LIFETIME SAVINGS</span>:
								<span class="values">{{user.details.lifeTimeSavings|currency:undefined:0}}</span>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

