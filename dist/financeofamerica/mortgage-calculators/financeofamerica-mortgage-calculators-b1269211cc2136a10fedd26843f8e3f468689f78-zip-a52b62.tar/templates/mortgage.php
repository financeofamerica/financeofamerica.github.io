<div id="calculator" class="mortgage-calculator breaker-block" ng-app="mortCalcApp">
	<div ng-controller="DoughnutCtrl">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 col-md-4 col-lg-3">
					<label for="homePrice">Home price <span class="price">{{user.details.homePrice|currency:undefined:0}}</span> </label>
					<div class="input-group mb-3">
						<input type="range" class="custom-range" ng-change="calculate('hprice')" min="50000" max="5000000" step="100" ng-model="user.details.homePrice" value="user.details.homePrice"  id="homePrice">
					</div>
					<label for="downPayment">Down payment</label>
					<div class="row">
						<div class="col-6 col-md-12 col-lg-6 pr-0 pr-md-3 pr-lg-0">
							<div class="input-group mb-3">
								<div class="input-group-prepend">
                                    <span class="input-group-text">
                                        $
                                    </span>
								</div>
								<input type="number" style="" ng-keyup="calculate('dpayment')" class="form-control" ng-model="user.details.downPayment" name="downPayment" fraction-size="0" id="downPayment" maxlength="30" />
							</div>
						</div>
						<div class="col-6 col-md-12 col-lg-6">
							<div class="input-group mb-3">
								<input type="number" style="" ng-keyup="calculate('dpercent')" class="form-control" ng-model="user.details.dpayPercent" name="dpayPercent" id="dpayPercent" maxlength="5" />
								<div class="input-group-append">
                                    <span class="input-group-text">
                                        %
                                    </span>
								</div>
							</div>
						</div>
					</div>
					<label for="loanProgram">Loan program</label>
					<div class="input-group mb-3 select-wrapper">
					<span aria-hidden="true"><i class="arrow-down-icon"></i></span>
						<select ng-change="calculate('lprogram')" ng-init="user.details.loanProgram='30'" ng-model="user.details.loanProgram" name="loanProgram" id="loanProgram" ng-pattern="" required>
							<option value="30">30-year fixed</option>
							<option value="15">15-year fixed</option>
							<option value="5">5/1 ARM</option>
						</select>
					</div>
					<label for="interestRate">Interest rate <span style="color:#790000">*</span></label>
					<div class="input-group mb-3">
						<input type="number" min="0 " class="form-control" ng-keyup="calculate('rate')" ng-model="user.details.interestRate" name="interestRate" id="interestRate" maxlength="10" />
						<div class="input-group-append">
                            <span class="input-group-text radius-left">
                                %
                            </span>
						</div>
					</div>
					<div ng-show="!simple">
						<label class="custom-control fill-checkbox mb-3">
							<input type="checkbox" ng-change="calculate()" class="fill-control-input" ng-model="user.details.incTaxIns" name="showTaxes" id="incTaxIns" />
							<span class="fill-control-indicator"></span>
							<span class="fill-control-description">Include taxes/ins.</span>
						</label>
						<div class="form-inline" ng-show="user.details.incTaxIns">
							<label for="taxes">Property tax</label>
							<div class="row">
								<div class="col-md-12">
									<div class="input-group mb-3">
										<div class="input-group-prepend">
                                            <span class="input-group-text">
                                                $
                                            </span>
										</div>
										<input type="number" style="" ng-keyup="calculate('ptax')" class="form-control" ng-model="user.details.taxes" name="taxes" id="taxes" maxlength="10" />
										<div class="input-group-append">
											<span class="input-group-text">/mo</span>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="input-group mb-3">
										<input type="number" style="" ng-keyup="calculate('ptaxPercent')" class="form-control" ng-model="user.details.taxPercent" name="taxPercent" id="taxPercent" maxlength="5" />
										<div class="input-group-append">
                                            <span class="input-group-text">
                                                %
                                            </span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div ng-show="user.details.incTaxIns">
							<label for="homeInsurance">Home insurance</label>
							<div class="input-group mb-3">
								<div class="input-group-prepend">
                                    <span class="input-group-text">
                                        $
                                    </span>
								</div>

								<input type="text" ng-keyup="calculate()" class="form-control" ng-model="user.details.homeInsurance" name="homeInsurance" id="homeInsurance" />
								<div class="input-group-append">
                                    <span class="input-group-text">
                                        /mo
                                    </span>
								</div>
							</div>
						</div>
						<div class="form-inline" ng-show="user.details.incTaxIns">
							<label class="custom-control fill-checkbox mb-3">
								<input type="checkbox" class="fill-control-input" ng-change="calculate()" ng-model="user.details.incPMI" name="incPMI" id="incPMI" />
								<span class="fill-control-indicator"></span>
								<span class="fill-control-description">Include PMI.</span>
							</label>
						</div>
						<label for="hoaDues">HOA dues</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
                                <span class="input-group-text">
                                    $
                                </span>
							</div>
							<input type="number" ng-keyup="calculate()" class="form-control" ng-model="user.details.hoaDues" name="hoaDues" id="hoaDues" />
							<div class="input-group-append">
                                <span class="input-group-text">
                                    /mo
                                </span>
							</div>
						</div>
					</div>
					<div class="simple" ng-show="simple"><a href="" ng-click="simple = false">Advanced<span aria-hidden="true"><i class="fa fa-chevron-down"></i></span></a></div>
					<div class="simple" ng-show="!simple"><a href="" ng-click="simple = true">Simple<span aria-hidden="true"><i class="fa fa-chevron-up"></i></span></a></div>
				</div>
				<div class="col-12 col-sm-12 col-md-8 col-lg-9" style="display: table;">
					<div class="chart-wrapper">
						<div class="row">
							<div class="col-8 mx-auto col-sm-8 col-md-8 col-lg-5">
								<div class="payment-wrapper">
									<span class="payment">{{user.details.yourPayment|currency:undefined:0}}</span>
									<span class="payment-txt">Monthly Payment</span>
								</div>
								<div class="chart-container">
									<canvas role="img" aria-label="This chart contains data that is also available in the following amortization schedule breakdown table." id="doughnut" chart-colors="colors" class="chart chart-doughnut" style="width:100%;height:100%;float: left;" height="390" width="390" chart-data="data" chart-dataset-override="datasetOverride" chart-options="options" chart-labels="labels"></canvas>
								</div>
							</div>
							<div class="col-12 col-sm-12 col-md-12 col-lg-7" style="margin: auto 0;">
								<ul class="color-codes">
									<li>
										<div class="row align-items-center justify-content-between">
											<div class="col-7">
												<div class="color-code color1"></div>
												<p class="labels">{{labels[0]}}</p>
											</div>
											<div class="col-5">
												<span style="line-height: 44px; padding-right:12px" class="values">{{data[0]|currency:undefined:0}}</span>
											</div>
										</div>
									</li>
									<li ng-show="user.details.incTaxIns">
										<div class="row align-items-center justify-content-between">
											<div class="col-7">
												<div class="color-code color2"></div>
												<p class="labels">{{labels[1]}}</p>
											</div>
											<div class="col-5">
												<div class="input-group">
													<div class="input-group-prepend">
                                                        <span class="input-group-text addition">
                                                            +
                                                        </span>
													</div>
													<div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            $
                                                        </span>
													</div>
													<input type="number" style="" ng-keyup="calculate('ptax')" class="form-control" ng-model="user.details.taxes" name="taxes" id="taxes" maxlength="10" />
												</div>
											</div>
										</div>
									</li>
									<li>
										<div class="row align-items-center justify-content-between">
											<div class="col-7">
												<div class="color-code color3"></div>
												<p class="labels">{{labels[2]}}</p>
											</div>
											<div class="col-5">
												<div class="input-group">
													<div class="input-group-prepend">
                                                        <span class="input-group-text addition">
                                                            +
                                                        </span>
													</div>
													<div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            $
                                                        </span>
													</div>
													<input type="number" ng-keyup="calculate()" class="form-control" ng-model="user.details.homeInsurance" name="homeInsurance" id="homeInsurance" />
												</div>
											</div>
										</div>
									</li>
									<li ng-show="user.details.incPMI">
										<div class="row align-items-center justify-content-between">
											<div class="col-7">
												<div class="color-code color4"></div>
												<p class="labels">{{labels[3]}}</p>
											</div>
											<div class="col-5">
												<span class="addition-span">+</span>
												<span style="line-height: 44px; padding-right:12px;" class="values">{{data[3]|currency:undefined:0}}</span>
											</div>
										</div>
									</li>
									<li>
										<div class="row align-items-center justify-content-between">
											<div class="col-7">
												<div class="color-code color5"></div>
												<p class="labels">{{labels[4]}}</p>
											</div>
											<div class="col-5">
												<div class="input-group">
													<div class="input-group-prepend">
                                                        <span class="input-group-text addition">
                                                            +
                                                        </span>
													</div>
													<div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            $
                                                        </span>
													</div>
													<input type="number" ng-keyup="calculate()" class="form-control" ng-model="user.details.hoaDues" name="hoaDues" id="hoaDues" />
												</div>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
