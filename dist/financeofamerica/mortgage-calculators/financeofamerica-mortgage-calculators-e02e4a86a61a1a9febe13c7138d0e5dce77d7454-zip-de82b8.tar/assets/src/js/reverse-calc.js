

function buildChart(calc) {
    updateChart('HECMChart', calc['HECM']);
    updateLegend('HECM', calc['HECM']);

    if (calc['HomeSafe']['proceeds'] != 'invalid') {
        jQuery('#homesafe-invalid').hide();
        jQuery('#homesafe-holder').show();
        jQuery('#homesafe-wrapper').show();
        updateChart('HSChart', calc['HomeSafe']);
        updateLegend('HS', calc['HomeSafe']);
    } else {
        jQuery('#homesafe-wrapper').hide();
        jQuery('#homesafe-invalid').show();

    }
    
    localStorage.setItem('calculatorResults', JSON.stringify(calc));
}


function updateChart(chart, stats) {
    var config = {
        type: 'pie',
        data: {
            datasets: [{
                data: [
                    Math.abs(stats['payoff']),
                    Math.abs(stats['funds']),
                    Math.abs(stats['equity']),
                ],
                backgroundColor: [
                    "rgba(6, 50, 90, 1)",
                    "rgba(91, 126, 150, 1)",
                    "rgba(0, 167, 219, 1)"
                ],
                label: 'Data'
            }],
            labels: [
                'Mortgage Payoff',  
                'Available Proceeds',
                'Remaining Equity'
            ]
        },
        options: {
            responsive: true,
            aspectRatio: 2,
            cutoutPercentage: 25,
            legend: {
                display: false,
                position: 'top',
            },
            title: {
                display: false,
            },
            tooltips: {
                enabled: false
            },
        }
    };
    var ctx = document.getElementById(chart).getContext('2d');
    window.myDoughnut = new Chart(ctx, config);
}

function updateLegend(chart, stats) {
    var payoff = "$" + stats['payoff'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    var funds = "$" + Math.abs(stats['funds']).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    var equity = "$" + stats['equity'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    var ttlProceeds = "$" + stats['proceeds'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    
    jQuery('#' + chart + 'payoff').html(payoff);
    jQuery('#' + chart + 'funds').html(funds);
    jQuery('#' + chart + 'equity').html(equity);

    if (stats['funds'] < 0) {
        jQuery('#' + chart + 'label').html("Funds to Close");
        jQuery('#' + chart + 'funds').addClass("orange");
        jQuery('#' + chart + 'text').html("Funds to Close");
        jQuery('#' + chart + 'proceeds').addClass("orange");
        jQuery("#" + chart + "proceeds").html(funds);
    } else {
        jQuery('#' + chart + 'label').html("Available Proceeds");
        jQuery('#' + chart + 'funds').removeClass("orange");
        jQuery('#' + chart + 'text').html("Total Proceeds");
        jQuery('#' + chart + 'proceeds').removeClass("orange");
        jQuery("#" + chart + "proceeds").html(ttlProceeds);
    }
}

function loadData() {
    var state = document.getElementById("state").value;
    var age = document.getElementById("age").value;
    var home_value = parseInt(document.getElementById("home_value").value.replace("$", "").replace(/,/g, ""));
    var mortgage_balance = parseInt(document.getElementById("mortgage_balance").value.replace("$", "").replace(/,/g, ""));
        
    var data = {
        "action": "loan_calc_action",
        "age": age,
        "home_value": home_value,
        "mortgage_balance": mortgage_balance,
        "state": state
    };

    jQuery.post(ajaxObj.ajax_url, data, function(response) {
        buildChart(JSON.parse(response));
    });
}

function updateState() {
    jQuery("#property-state").html(jQuery("#state option:selected").text());
    loadData();
}

jQuery(document).ready(function($) {
    if($('.reverse-calculator').length) {
        updateState();	
        jQuery("#home_value").keyup(loadData);
        jQuery("#mortgage_balance").keyup(loadData);
        jQuery("#state").change(updateState);
        jQuery("#age").change(loadData);
    }
});