# Changelog

Relevant changes to the Mortgage Calculator project are documented below as a resource for users.

## [1.0.0] - 2018-04-23
### Added
- Move loan-calculators plugin as the base for this project
- Accurate Reverse Mortgage Calculator

### Changed
- N/A
