<?php

if ( class_exists( 'GFForms' ) ) {
	

class GFA_Field_ReverseCalc extends GF_Field {

	public $type = 'foa_reverse_mortgage_calc';

	public function __construct( $data = array() ) {
		parent::__construct($data);
	}

	public function get_form_editor_field_title() {
		return esc_attr__( 'Reverse Mortgage', 'gravityforms' );
	}

	public function get_field_input( $form, $value = '', $entry = null ) {
		/*
		$is_entry_detail = $this->is_entry_detail();
		$is_form_editor  = $this->is_form_editor();
		$is_admin        = $is_form_editor || $is_entry_detail;

		$id                 = (int) $this->id;
		$tabindex           = $this->get_tabindex();
		$disabled_text      = $is_form_editor ? 'disabled="disabled"' : '';
		
		
		if ( $is_admin && ! GFCommon::is_entry_detail_edit() ) {
			$checkbox_label = ! is_array( $value ) || empty( $value[ $id . '.2' ] ) ? $this->checkboxLabel : $value[ $id . '.2' ];
			$revision_id    = ! is_array( $value ) || empty( $value[ $id . '.3' ] ) ? GFFormsModel::get_latest_form_revisions_id( $form['id'] ) : $value[ $id . '.3' ];
			$value          = ! is_array( $value ) || empty( $value[ $id . '.1' ] ) ? '0' : esc_attr( $value[ $id . '.1' ] );
		} else {
			$checkbox_label = $this->checkboxLabel;
			$revision_id    = GFFormsModel::get_latest_form_revisions_id( $form['id'] );
			// We compare if the description text from different revisions has been changed.
			$current_description   = $this->get_field_description_from_revision( $revision_id );
			$submitted_description = $this->get_field_description_from_revision( $value[ $id . '.3' ] );

			$value = ! is_array( $value ) || empty( $value[ $id . '.1' ] ) || ( $this->checkboxLabel !== $value[ $id . '.2' ] ) || ( $current_description !== $submitted_description ) ? '0' : esc_attr( $value[ $id . '.1' ] );
		}

		$input  = "<input type='hidden' name='input_{$id}.1' id='rev_calc_age' value='' class='gform_hidden' />";
		$input .= "<input type='hidden' name='input_{$id}.2' id='rev_calc_homeval' value='' class='gform_hidden' />";
		$input .= "<input type='hidden' name='input_{$id}.3' id='rev_calc_mortgage' value='' class='gform_hidden' />";
		$input .= "<input type='hidden' name='input_{$id}.4' id='rev_calc_state' value='' class='gform_hidden' />";
		$input .= "<input type='hidden' name='input_{$id}.5' id='rev_calc_hecm' value='' class='gform_hidden' />";
		$input .= "<input type='hidden' name='input_{$id}.6' id='rev_calc_homesafe' value='' class='gform_hidden' />";
		
		if ( $is_entry_detail ) {
			// $input .= $this->get_description( $this->get_field_description_from_revision( $revision_id ), '' );
		}
		// $content = $this->do_shortcode( '[mortgage_calc type="reverse"]' );
		$content = GFCommon::replace_variables_prepopulate( "[mortgage_calc type='reverse']" ); // adding support for merge tags
		// adding support for shortcodes
		$content = $this->do_shortcode( $content );
		//return sprintf( "<div class='ginput_container ginput_container_calculator'>%s</div>", $content );
		*/
		return("show the calc");
/*


		// Original Code
		if ($is_form_editor || $is_entry_detail) {
			$content =  "<div class='gf-calc-container gf-html-container'><span class='gf_blockheader'>
				<i class='fa fa-code fa-lg'></i> " . esc_html__( 'Reverse Mortgage Calculator', 'gfaddon' ) .
				'</span><span>This block contains the a <b>Reverse/HECM</b> Mortgage Calculator.</span></div>';
		} else {
			$content = GFCommon::replace_variables_prepopulate( $content ); // adding support for merge tags
			// adding support for shortcodes
			$content = $this->do_shortcode( $content );
		}

		return $content;
		*/
	}

	public function get_field_content( $value, $force_frontend_label, $form ) {
		$form_id         = $form['id'];
		$admin_buttons   = $this->get_admin_buttons();
		$is_entry_detail = $this->is_entry_detail();
		$is_form_editor  = $this->is_form_editor();
		$is_admin        = $is_entry_detail || $is_form_editor;
		$field_label     = $this->get_field_label( $force_frontend_label, $value );
		$field_id        = $is_admin || $form_id == 0 ? "input_{$this->id}" : 'input_' . $form_id . "_{$this->id}";
		$field_content   = ! $is_admin ? '{FIELD}' : $field_content = sprintf( "%s<label class='gfield_label' for='%s'>%s</label>{FIELD}", $admin_buttons, $field_id, esc_html( $field_label ) );

		return $field_content;

	}

	public function get_form_inline_script_on_page_render( $form ) {
		return '';
	}

}

GF_Fields::register( new GFA_Field_ReverseCalc() );

}