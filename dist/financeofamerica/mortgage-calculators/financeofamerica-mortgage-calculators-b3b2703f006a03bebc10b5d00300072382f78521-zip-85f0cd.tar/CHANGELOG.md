# Changelog

Relevant changes to the Mortgage Calculator project are documented below as a resource for users.

## [1.0.6] - 2019-06-11
### Changed
- Version bump 

## [1.0.5] - 2019-06-11
### Added
- Settings fields for MAX proceeds

### Changed
- Calculation changed to manage MAX proceeds 

# [1.0.4] - 2019-06-05
### Changed
- Version bump

## [1.0.3] - 2019-06-05
### Changed
- Style sheet and JS loading priority

## [1.0.2] - 2019-05-31
### Added
- Additional Mortgage Calculators

## [1.0.0] - 2018-04-23
### Added
- Move loan-calculators plugin as the base for this project
- Accurate Reverse Mortgage Calculator

### Changed
- N/A
