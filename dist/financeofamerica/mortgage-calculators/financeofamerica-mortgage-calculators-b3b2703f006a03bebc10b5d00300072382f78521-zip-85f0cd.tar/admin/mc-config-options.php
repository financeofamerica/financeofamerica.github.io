<?php

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}


if ( ! class_exists( 'MC_Config_Settings_Page' ) ) :
/* Best Practices Settings Page */
class MC_Config_Settings_Page {
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'create_settings' ) );
		add_action( 'admin_init', array( $this, 'setup_sections' ) );
		add_action( 'admin_init', array( $this, 'setup_fields' ) );
	}
	public function create_settings() {
		$page_title = 'Mortgage Calculators Configuration';
		$menu_title = 'Calculators';
		$capability = 'manage_options';
		$slug = 'mortgagecalcs';
		$callback = array($this, 'settings_content');
		add_options_page($page_title, $menu_title, $capability, $slug, $callback);
	}
	public function settings_content() { ?>
		<div class="wrap">
		<?php settings_errors(null, false, true); ?>
			<h1>Mortgage Calculator Configuration</h1>
			<form method="POST" action="options.php">
				<?php
					settings_fields( 'reverse' );
					do_settings_sections( 'reverse' );
					submit_button();
				?>
			</form>
		</div> <?php

	}
	public function setup_sections() {
		add_settings_section( 'reverse_section', 'Configure HECM and HomeSafe&reg; Calculator settings.', array(), 'reverse' );
	}
	public function setup_fields() {
		$usStates = json_decode(file_get_contents(dirname(__DIR__) . '/data/us-states.json'), true);
		$hecmOptions = array();
		for ($i = 3; $i <= 20; $i = $i + 0.125 ) {
			$v = number_format($i,3);
			$hecmOptions[$v] = $v;
		}
		$hsOptions = array();
		for ($i = 3.99; $i <= 10; $i = $i + 0.5 ) {
			$v = number_format($i,2);
			$hsOptions[$v] = $v;
		}
		$fields = array(
			array(
				'label' => 'HECM Max Value',
				'id' => 'mc-hecm-max',
				'type' => 'text',
				'section' => 'reverse_section',
				'placeholder' => '679650'
			),
			array(
				'label' => 'HECM Max Proceeds',
				'id' => 'mc-hecm-max-proceeds',
				'type' => 'text',
				'section' => 'reverse_section',
				'placeholder' => '679650'
			),
			array(
				'label' => 'HECM Rate Table',
				'id' => 'mc-hecm-rate',
				'type' => 'textarea',
				'section' => 'reverse_section',
				'height' => 10,
				'width' => 20,
			),
			array(
				'label' => 'HomeSafe&reg; Max Value',
				'id' => 'mc-homesafe-max',
				'type' => 'text',
				'section' => 'reverse_section',
				'placeholder' => '600000'
			),
			array(
				'label' => 'HomeSafe&reg; Max Proceeds',
				'id' => 'mc-homesafe-max-proceeds',
				'type' => 'text',
				'section' => 'reverse_section',
				'placeholder' => '4000000'
			),
			array(
				'label' => 'HomeSafe&reg; Rate Table',
				'id' => 'mc-homesafe-rate',
				'type' => 'textarea',
				'section' => 'reverse_section',
				'height' => 10,
				'width' => 20,
			),
			array(
				'label' => 'HomeSafe&reg; Approved States',
				'id' => 'mc-homesafe-states',
				'type' => 'checkbox',
				'section' => 'reverse_section',
				'options' => $usStates,
			),
			array(
				'label' => 'Load Bootstrap',
				'id' => 'mc-load-bootstrap',
				'type' => 'checkbox',
				'section' => 'reverse_section',
				'options' => array("Yes"),
			),
			array(
				'label' => 'Load Bootstrap Select',
				'id' => 'mc-load-bootstrap-select',
				'type' => 'checkbox',
				'section' => 'reverse_section',
				'options' => array("Yes"),
			),
		);
		foreach( $fields as $field ){
			add_settings_field( $field['id'], $field['label'], array( $this, 'field_callback' ), 'reverse', $field['section'], $field );
			register_setting( 'reverse', $field['id'] );
		}
	}

	public function field_callback( $field ) {
		$value = get_option( $field['id'] );
		switch ( $field['type'] ) {
			case 'radio':
			case 'checkbox':
				if( ! empty ( $field['options'] ) && is_array( $field['options'] ) ) {
					$options_markup = '';
					$iterator = 0;
					foreach( $field['options'] as $key => $label ) {
						$iterator++;
						$options_markup.= sprintf('<label for="%1$s_%6$s"><input id="%1$s_%6$s" name="%1$s[]" type="%2$s" value="%3$s" %4$s /> %5$s</label><br/>',
						$field['id'],
						$field['type'],
						$key,
						checked($value[array_search($key, $value, true)], $key, false),
						$label,
						$iterator
						);
					}
					printf( '<fieldset>%s</fieldset>',$options_markup);
				}
				break;
			case 'select':
			case 'multiselect':
				if( ! empty ( $field['options'] ) && is_array( $field['options'] ) ) {
					$attr = '';
					$options = '';
					foreach( $field['options'] as $key => $label ) {
						$options.= sprintf('<option value="%s" %s>%s</option>',
							$key,
							selected($value[array_search($key, $value, true)], $key, false),
							$label
						);
					}
					if( $field['type'] === 'multiselect' ){
						$attr = ' multiple="multiple" ';
					}
					printf( '<select name="%1$s[]" id="%1$s" %2$s>%3$s</select>',
						$field['id'],
						$attr,
						$options
					);
				}
				break;
			case 'textarea':
				$rows = (isset($field['height'])) ? $field['height'] : "5";
				$cols = (isset($field['width'])) ? $field['width'] : "20";

				printf( '<textarea name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" cols="%5$s" rows="%6$s">%4$s</textarea>',
					$field['id'],
					$field['type'],
					$field['placeholder'],
					$value,
					$cols,
					$rows
				);		
				break;
			default:
				printf( '<input name="%1$s" id="%1$s" type="%2$s" placeholder="%3$s" value="%4$s" />',
					$field['id'],
					$field['type'],
					$field['placeholder'],
					$value
				);
		}
		if( $desc = $field['desc'] ) {
			printf( '<p class="description">%s </p>', $desc );
		}
	}
}
new MC_Config_Settings_Page();

endif;
