<?php


class TwoX_JSON_File_Process extends WP_Background_Process {

	/**
	 * @var string
	 */
	protected $action = 'twox_download_json_process';

	
	/**
	 * Task
	 *
	 * @param mixed $item Queue item to iterate over
	 *
	 * @return mixed
	 */
	protected function task( $item ) {
		
		$json = TwoX_SiteInfo::fileFetch($item['type'], $item['id']);
		if ($item['type'] == 'tpo-employee') {
			$employee = get_page_by_path( $item['id'], OBJECT, 'tpo_employees' );
			if (!$employee) {
				$intro = (isset($json['short_bio'])) ? $json['short_bio'] : $this->first_sentence($json['long_bio']);
                if ($json['user_role'] == 'account_executive') {
                    $user_role = 'Account Executive';
                } elseif ($json['user_role'] == 'regional_manager') {
                    $user_role = 'Regional Manager';
                } elseif ($json['user_role'] == 'support_staff') {
                    $user_role = 'Support Staff';
                }
				wp_insert_post( array('post_title' => "{$json['first_name']} {$json['last_name']} - {$user_role}", 'post_name' => $json['id'], 'post_excerpt' => $intro, 'post_type' => 'tpo_employees', 'post_status' => 'publish')) ;
			}
		}
		
		return false;
	}

	private function first_sentence($content) {

        $content = html_entity_decode(strip_tags($content));
        $pos = strpos($content, '.');
           
        if($pos === false) {
            return $content;
        }
        else {
            return substr($content, 0, $pos+1);
        }
       
	}
	
	/**
	 * Complete
	 *
	 * Override if applicable, but ensure that the below actions are
	 * performed, or, call parent::complete().
	 */
	protected function complete() {
		parent::complete();

		// Show notice to user or perform some other arbitrary task...
	}

}
