<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use GuzzleHttp\Pool;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Psr\Log\LoggerInterface;

if ( ! class_exists( 'TwoX_REST_Controller' ) ) {
	class TwoX_REST_Controller extends WP_REST_Controller {
		/**
         * @var GuzzleClient
         */
		protected static $client = null;

		/**
         * @var string
         */
        protected static $url = null;

        /**
         * @var string
         */
		protected static $token = null;


		public function __construct( $type = null ) {
            $this->namespace = 'twox';

            $baseUrl = get_option('twox_endpoint', null);
			$ApiVersion = get_option('twox_version', 'v1');
			$ApiVersion = (is_array($ApiVersion)) ? $ApiVersion[0] : $ApiVersion;

			self::$url = "{$baseUrl}/wp-json/foa/{$ApiVersion}/";
            self::$token = get_option('twox_sitekey', null);

            // parent::__construct();
		}

		public function get_item_permissions_check( $request ) {
			return true;
		}

		public function register_routes() {
			register_rest_route( $this->namespace, '/info/?', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_info' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			) );

			register_rest_route( $this->namespace, '/tpo-employee/id/(?P<id>[a-zA-Z0-9-]+)/?', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_tpo_employee' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			) );


			register_rest_route( $this->namespace, '/tpo-employee/search/(?P<term>[a-zA-Z]+\.?((\%20|\-)[a-zA-Z]+\.?)*)/?', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search_tpo_employee' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			) );

		}

		public function register() {
			$this->register_routes();
		}

		/**
         * @return GuzzleClient
         */
        public static function getClient()
        {
            if (!self::$client) {
                self::$client = new Client(
                    [
                        'base_uri' 			=> self::$url,
                        'allow_redirects' 	=> false,
                        'cookies'         	=> false,
						'headers' 			=> ['twoxsite' => self::$token ],
						'query'				=> ['v' => time()]
                    ]
                );
            }

            return self::$client;
		}

		public function get_info( $request ) {
			$info = array (
				'host' => get_option('twox_endpoint'),
				'key' =>  get_option('twox_sitekey'),
				'uploads' =>  preg_replace("/[\\/]/", "", urlencode(get_option('twox_filepath')))
			);

			return $info;
		}


		public function get_nmls( $request ) {
            $result = false;
            $nmls =  (isset($request['nmls'])) ? preg_replace( "/[^0-9]+/", "", $request['nmls']) : false;

			try {
                $call = "employee/nmls/{$nmls}";
                $response = self::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $result = json_decode($response->getBody(true)->getContents(),true);
                }

            } catch (Exception $e) {
                $result = new WP_Error( 'twox_info_nmls', $e->getCode() . ' -> ' . $e->getMessage() , array( 'status' => 404 ) );
            }

            $response = new WP_REST_Response( $result );
			$response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
            return $response;

		}

		public function get_branch( $request ) {
            $result = false;
            //$id =  (isset($request['id'])) ? preg_replace( "/[^0-9]+/", "", $request['nmls']) : false;
            $filename = $request->get_param( 'id' );
            $filename = filter_var($filename, FILTER_SANITIZE_STRING);

			try {
                $call = "branch/id/{$filename}";
                $response = self::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $result = json_decode($response->getBody(true)->getContents(),true);
                }

            } catch (Exception $e) {
                $result = new WP_Error( 'twox_info_branch_id', $e->getCode() . ' -> ' . $e->getMessage() , array( 'status' => 404 ) );
            }

            $response = new WP_REST_Response( $result );
			$response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
            return $response;

		}

		public function get_branch_bystate( $request ) {
            $result = false;
            //$id =  (isset($request['id'])) ? preg_replace( "/[^0-9]+/", "", $request['nmls']) : false;
            $term = $request->get_param( 'term' );
            $term = filter_var($term, FILTER_SANITIZE_STRING) . '';

			try {
				$call = ($term != '') ? "branch/list/{$term}" : "branch/list/all";
                $response = self::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $result = json_decode($response->getBody(true)->getContents(),true);
                }

            } catch (Exception $e) {
                $result = new WP_Error( 'twox_info_branch_list', $e->getCode() . ' -> ' . $e->getMessage() , array( 'status' => 404 ) );
            }

            $response = new WP_REST_Response( $result );
			$response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
            return $response;

        }

		public function get_tpo_employee( $request ) {
            $result = false;
            //$id =  (isset($request['id'])) ? preg_replace( "/[^0-9]+/", "", $request['nmls']) : false;
            $filename = $request->get_param( 'id' );
            $filename = filter_var($filename, FILTER_SANITIZE_STRING);

			try {
                $call = "tpo-employee/id/{$filename}";
                $response = self::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $result = json_decode($response->getBody(true)->getContents(),true);
                }

            } catch (Exception $e) {
                $result = new WP_Error( 'twox_info_tpo_employee_id', $e->getCode() . ' -> ' . $e->getMessage() , array( 'status' => 404 ) );
            }

            $response = new WP_REST_Response( $result );
			$response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
            return $response;

		}

		public function search_tpo_employee( $request ) {
            $result = false;
            //$id =  (isset($request['id'])) ? preg_replace( "/[^0-9]+/", "", $request['nmls']) : false;
            $term = $request->get_param( 'term' );
            $term = filter_var($term, FILTER_SANITIZE_STRING);

			try {
                $call = "search/tpo-employee/{$term}";
                $response = self::getClient()->get($call);

                if ($response->getStatusCode() == '200') {
                    $result = json_decode($response->getBody(true)->getContents(),true);
                }

            } catch (Exception $e) {
                $result = new WP_Error( 'twox_info_tpo_employee_search', $e->getCode() . ' -> ' . $e->getMessage() , array( 'status' => 404 ) );
            }

            $response = new WP_REST_Response( $result );
			$response->header('Cache-Control', 'no-cache, must-revalidate, max-age=0');
            return $response;

		}
	}
}
