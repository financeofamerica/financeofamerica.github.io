# Changelog

Relevant changes to the TPO Info project are documented below as a resource for users.


## [0.1.0] - 2020-01-06
### Added
- Initial Coding to read from 2xLO Rest API for TPO

### Changed
- N/A
