# Changelog

Changes to the Alquemie Social Survey API Wrapper

## [0.1.0] - 2018-10-22
### Added
Initial Class Release
- Get SURVEYS method
- SURVEYCOUNT method


