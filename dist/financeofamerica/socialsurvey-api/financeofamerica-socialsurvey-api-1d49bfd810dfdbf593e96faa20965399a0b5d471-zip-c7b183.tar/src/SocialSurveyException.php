<?php

namespace SocialSurveyApi;

/**
 * Default exception class
 */
class SocialSurveyException extends \Exception
{

}