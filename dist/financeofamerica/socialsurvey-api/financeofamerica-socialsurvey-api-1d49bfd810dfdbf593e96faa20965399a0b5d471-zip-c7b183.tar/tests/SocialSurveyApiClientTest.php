<?php

namespace SocialSurveyApi\Tests;

use SocialSurveyApi\SocialSurveyApiClient;

/**
 * @author Brent Mullen <brent.mullen@gmail.com>
 */
class SocialSurveyApiClientTest extends \PHPUnit_Framework_TestCase
{
    /** Todo: write them */
}