# Changelog

Relevant changes to the Alquemie Config project are documented below as a resource for users.

## [0.1.2] - 2018-10-19
### Changed
- Context Fixes

## [0.1.1] - 2018-10-19
### Added
- Admin Settings Page

### Changed
- Functionality can be disabled based on setting
- Messages can be customized 

## [0.1.0] - 2018-10-01
### Added
- Remove Author URLs
- Change "Howdy" to "Logged in as" 
- Delay posts from RSS by 12 hours
- Remove "Generator" header
- Customized Dashboard Footer text

### Changed
- N/A
