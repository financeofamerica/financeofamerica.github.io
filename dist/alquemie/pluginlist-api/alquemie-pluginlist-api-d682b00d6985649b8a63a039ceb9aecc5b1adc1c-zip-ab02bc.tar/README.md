# PluginList API

Add REST API endpoint of current plugins

## Description

Used to monitor site plugin versions for automated reporting tools.

## Installation

If you don't know how to do this, then you probably don't have a need for this plugin

## Frequently Asked Questions

###  Who do I ask if I need assistance? =

Finance of America Marketing Technology Team
